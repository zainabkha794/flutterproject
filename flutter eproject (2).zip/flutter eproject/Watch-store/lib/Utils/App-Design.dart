import 'package:flutter/material.dart';

class AppDesign {
  static const appName = "watchstore";

  // Text Colors
  static const appTextColor = Colors.white;
  static const appHeadingColor = Color.fromARGB(255, 1, 0, 42);

  // Primary Colors
  static const appPrimaryColor = Color.fromARGB(255, 0, 45, 82);
  static const appSecondaryColor = Color.fromARGB(255, 0, 0, 0);

  // Background Gradient
  static const appGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
       Color.fromARGB(255, 0, 51, 255), // Blue
      Color.fromARGB(255, 44, 26, 115), // Purple
      Color.fromARGB(255, 5, 3, 85), // Deep Blue
    ],
  );

  // Footer
  static const appFooterText = "App Design By watchstore";
  static const appFooterTextColor = Colors.white;
}

