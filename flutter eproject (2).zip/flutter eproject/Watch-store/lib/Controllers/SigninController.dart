// ignore_for_file: use_build_context_synchronously

import 'package:watchstore/Screens/Admin-Panel/Home.dart';
import 'package:watchstore/Screens/User-Panel/home.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

class SigninProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// ---------- Email/Password Login ----------
  Future<void> signinValidation({
    required TextEditingController email,
    required TextEditingController pass,
    required BuildContext context,
  }) async {
    if (email.text.isEmpty) {
      showError(context, "Email is required");
      return;
    }
    if (pass.text.isEmpty) {
      showError(context, "Password is required");
      return;
    }
    if (pass.text.length < 4) {
      showError(context, "Password must be at least 4 characters");
      return;
    }
    try {
      EasyLoading.show(status: 'Please wait...');
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email.text.trim(),
        password: pass.text.trim(),
      );
      await _handleUserRedirect(context, userCredential.user);
    } on FirebaseAuthException catch (e) {
      EasyLoading.dismiss();
      showError(context, e.message ?? "Login failed, please try again.");
    }
  }

  Future<void> _handleUserRedirect(BuildContext context, User? user) async {
    if (user == null) return;

    DocumentSnapshot userData = await _firestore
        .collection("users")
        .doc(user.uid)
        .get();
        
    EasyLoading.dismiss();
    EasyLoading.showSuccess('Login successful');

    if (userData['role'] == 'admin') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => AdminDashboard()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => Homescreen()),
      );
    }
  }

  void showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }
}
