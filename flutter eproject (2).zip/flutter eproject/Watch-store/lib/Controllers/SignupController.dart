// ignore_for_file: use_build_context_synchronously

import 'package:watchstore/Screens/Auth-Panel/Login-screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

class SignupProvider extends ChangeNotifier {
  UserCredential? userCredential;

  Future<void> signupValidation({
    required TextEditingController name,
    required TextEditingController email,
    required TextEditingController pass,
    required TextEditingController cpass,
    required BuildContext context,
  }) async {
    if (name.text.isEmpty) {
      showError(context, "Username is required");
      return;
    }

    if (email.text.isEmpty) {
      showError(context, "Email is required");
      return;
    }

    if (pass.text.isEmpty) {
      showError(context, "Password is required");
      return;
    }

    if (pass.text.length < 4) {
      showError(context, "Password must be at least 4 characters");
      return;
    }

    if (cpass.text.isEmpty) {
      showError(context, "Confirm Password is required");
      return;
    }

    if (pass.text != cpass.text) {
      showError(context, "Passwords do not match");
      return;
    }

    try {
      EasyLoading.show(status: 'Please wait...');

      userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
            email: email.text.trim(),
            password: pass.text.trim(),
          );

      await FirebaseFirestore.instance
          .collection("users")
          .doc(userCredential!.user!.uid)
          .set({
            "userid": userCredential!.user!.uid,
            "Name": name.text.trim(),
            "email": email.text.trim(),
            "createdAt": DateTime.now(),
            "role": "user",
            "image":""
          });

      name.clear();
      email.clear();
      pass.clear();
      cpass.clear();
      EasyLoading.showSuccess("Registration successful");
      Future.delayed(const Duration(seconds: 1), () {
        EasyLoading.dismiss();
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Login()),
        );
      });
    } on FirebaseAuthException catch (e) {
      EasyLoading.dismiss();
      showError(context, e.message ?? "Firebase Auth Error");
    } catch (e) {
      EasyLoading.dismiss();
      showError(context, "Unknown Error: $e");
    }
  }

  void showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }
}
