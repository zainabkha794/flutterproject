// ignore_for_file: use_build_context_synchronously

import 'package:watchstore/Screens/Admin-Panel/Order.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

class OrderProvider extends ChangeNotifier {
  Future<void> addOrder({
    required String bookid,
    required String userid,
    required String name,
    required String email,
    required String phone,
    required String address,
    required String city,
    required String postalcode,
    required String paymentMethod,
    required int orderquantity,
    required BuildContext context,
  }) async {
    if (name.isEmpty ||
        email.isEmpty ||
        phone.isEmpty ||
        address.isEmpty ||
        city.isEmpty ||
        postalcode.isEmpty) {
      showError(context, "Please fill all the fields");
      return;
    }

    try {
      EasyLoading.show(status: "Placing Order...");

      final docRef = FirebaseFirestore.instance.collection("orders").doc();

      await docRef.set({
        "orderId": docRef.id,
        "bookid": bookid,
        "userid": userid,
        "name": name.trim(),
        "email": email.trim(),
        "phone": phone.trim(),
        "address": address.trim(),
        "city": city.trim(),
        "postalcode": postalcode.trim(),
        "paymentMethod": paymentMethod,
        "orderquantity": orderquantity,
        "createdAt": DateTime.now(),
        "status": "Pending",
      });

      EasyLoading.showSuccess("Order placed successfully");

      Future.delayed(const Duration(seconds: 1), () {
        EasyLoading.dismiss();
        Navigator.pop(context);
      });
    } catch (e) {
      EasyLoading.dismiss();
      showError(context, "Failed to place order: $e");
    }
  }

  /// 🔹 Order Status Update Function
  Future<void> updateOrderStatus({
    required String orderId,
    required String newStatus,
    required BuildContext context,
  }) async {
    try {
      EasyLoading.show(status: "Updating...");

      await FirebaseFirestore.instance.collection("orders").doc(orderId).update(
        {"status": newStatus, "updatedAt": DateTime.now()},
      );

      EasyLoading.showSuccess("Status updated to $newStatus");

      Future.delayed(const Duration(seconds: 1), () {
        EasyLoading.dismiss();
        if (Navigator.canPop(context)) {
          Navigator.pop(context);
        } else {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => Orders()),
          );
        }
      });
    } catch (e) {
      EasyLoading.dismiss();
      showError(context, "Failed to update status: $e");
    }
  }

  /// 🔹 Error Snackbar
  void showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }
}
