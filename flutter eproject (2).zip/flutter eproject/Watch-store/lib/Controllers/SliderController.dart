// ignore_for_file: use_build_context_synchronously
import 'package:watchstore/Screens/Admin-Panel/Add-Slider.dart';
import 'package:watchstore/Screens/Admin-Panel/Update-Slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

class SliderProvider extends ChangeNotifier {
  Future<void> addSlider({
    required TextEditingController name,
    required TextEditingController image,
    required BuildContext context,
  }) async {
    if (name.text.trim().isEmpty) {
      showError(context, "Slider name is required");
      return;
    }
    if (image.text.trim().isEmpty) {
      showError(context, "Slider image URL is required");
      return;
    }

    try {
      EasyLoading.show(status: "Adding Slider...");

      final docRef = FirebaseFirestore.instance.collection("slider").doc();
      await docRef.set({
        "id": docRef.id,
        "name": name.text.trim(),
        "image": image.text.trim(),
        "createdAt": FieldValue.serverTimestamp(),
      });

      name.clear();
      image.clear();

      EasyLoading.showSuccess("Slider added successfully");
      Future.delayed(const Duration(seconds: 1), () {
        EasyLoading.dismiss();
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const Addslider()),
        );
      });
    } catch (e) {
      EasyLoading.dismiss();
      showError(context, "Failed to add slider: $e");
    }
  }

  Future<void> updateSlider({
    required String id,
    required TextEditingController name,
    required TextEditingController image,
    required BuildContext context,
  }) async {
    if (name.text.trim().isEmpty) {
      showError(context, "Slider name is required");
      return;
    }
    if (image.text.trim().isEmpty) {
      showError(context, "Slider image URL is required");
      return;
    }

    try {
      EasyLoading.show(status: "Updating slider...");

      await FirebaseFirestore.instance.collection("slider").doc(id).update({
        "name": name.text.trim(),
        "image": image.text.trim(),
        "updatedAt": FieldValue.serverTimestamp(),
      });

      name.clear();
      image.clear();

      EasyLoading.showSuccess("Slider updated successfully");
      Future.delayed(const Duration(seconds: 1), () {
        EasyLoading.dismiss();
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const UpdateSliderScreen(sliderId: '',sliderData: {},)),
        );
      });
    } catch (e) {
      EasyLoading.dismiss();
      showError(context, "Failed to update slider: $e");
    }
  }

  void showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.redAccent,
      ),
    );
  }
}
