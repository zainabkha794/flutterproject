// ignore_for_file: use_build_context_synchronously
import 'package:watchstore/Screens/Admin-Panel/Add-Category.dart';
import 'package:watchstore/Screens/Admin-Panel/Update-Category.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

class CategoryProvider extends ChangeNotifier {
  Future<void> addCategory({
    required TextEditingController name,
    required TextEditingController image,
    required BuildContext context,
  }) async {
    if (name.text.isEmpty) {
      showError(context, "Category name is required");
      return;
    }
    try {
      EasyLoading.show(status: "Adding category...");

      final docRef = FirebaseFirestore.instance.collection("categories").doc();
      await docRef.set({
        "categoryid": docRef.id,
        "name": name.text.trim(),
        "image": image.text.trim(),
        "createdAt": DateTime.now(),
      });

      name.clear();

      EasyLoading.showSuccess("Category added successfully");
      Future.delayed(const Duration(seconds: 1), () {
        EasyLoading.dismiss();
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => Addcategory()));
      });
    } catch (e) {
      EasyLoading.dismiss();
      showError(context, "Failed to add category: $e");
    }
  }

  Future<void> updateCategory({
    required String categoryId,
    required TextEditingController name,
    required TextEditingController image,
    required BuildContext context,
  }) async {
    try {
      EasyLoading.show(status: "Updating category...");

      await FirebaseFirestore.instance
          .collection("categories")
          .doc(categoryId)
          .update({
        "name": name.text.trim(),
        "image":image.text.trim(),
        "updatedAt": DateTime.now(),
      });

      name.clear();
      image.clear();

      EasyLoading.showSuccess("Category updated successfully");
      Future.delayed(const Duration(seconds: 1), () {
        EasyLoading.dismiss();
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => Updatecategory(categoryId: '',categoryData: {},)));
      });
    } catch (e) {
      EasyLoading.dismiss();
      showError(context, "Failed to update category: $e");
    }
  }

  void showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.redAccent,
      ),
    );
  }
}
