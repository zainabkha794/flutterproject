// ignore_for_file: use_build_context_synchronously

import 'package:watchstore/Screens/Admin-Panel/Add-Book.dart';
import 'package:watchstore/Screens/Admin-Panel/Update-Book.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';


class BookProvider extends ChangeNotifier {
  Future<void> addBook({
    required TextEditingController title,
    required TextEditingController procategory,
    required TextEditingController genre,
    required TextEditingController author,
    required TextEditingController price,
    required TextEditingController description,
    required TextEditingController image,
    required BuildContext context,
  }) async {
    if (!_validateFieldsController(
      title,
      procategory,
      genre,
      author,
      price,
      description,
      image,
      context,
    )) {
      return;
    }

    try {
      EasyLoading.show(status: "Adding book...");

      final docRef = FirebaseFirestore.instance.collection("books").doc();

      await docRef.set({
        "bookid": docRef.id,
        "title": title.text.trim(),
        "procategory": procategory.text.trim(),
        "genre": genre.text.trim(),
        "author": author.text.trim(),
    "price": double.tryParse(price.text.trim()) ?? 0.0,
        "description": description.text.trim(),
        "image": image.text.trim(),
        "createdAt": DateTime.now(),
      });

      _clearControllers([
        title,
        procategory,
        genre,
        author,
        price,
        description,
        image,
      ]);

      EasyLoading.showSuccess("Book added successfully");
      Future.delayed(const Duration(seconds: 1), () {
        EasyLoading.dismiss();
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const Addbook()),
        );
      });
    } catch (e) {
      EasyLoading.dismiss();
      showError(context, "Failed to add book: $e");
    }
  }

  Future<void> updateBook({
    required String bookId,
    required TextEditingController title,
    required String procategory,
    required TextEditingController genre,
    required TextEditingController author,
    required TextEditingController price,
    required TextEditingController description,
    required TextEditingController image,
    required BuildContext context,
  }) async {
    if (!_validateFieldsString(
      title,
      procategory,
      genre,
      author,
      price,
      description,
      image,
      context,
    )) {
      return;
    }

    try {
      EasyLoading.show(status: "Updating book...");
      final docRef = FirebaseFirestore.instance.collection("books").doc(bookId);

      await docRef.update({
        "title": title.text.trim(),
        "procategory": procategory,
        "genre": genre.text.trim(),
        "author": author.text.trim(),
      "price": double.tryParse(price.text.trim()) ?? 0.0,
        "description": description.text.trim(),
        "image": image.text.trim(),
        "updatedAt": DateTime.now(),
      });

      EasyLoading.showSuccess("Book updated successfully");

      Future.delayed(const Duration(seconds: 1), () {
        EasyLoading.dismiss();
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const Updatebook(bookId: '',bookData: {},)),
        );
      });
    } catch (e) {
      EasyLoading.dismiss();
      showError(context, "Failed to update book: $e");
    }
  }

  //For addBook//
  bool _validateFieldsController(
    TextEditingController title,
    TextEditingController procategory,
    TextEditingController genre,
    TextEditingController author,
    TextEditingController price,
    TextEditingController description,
    TextEditingController image,
    BuildContext context,
  ) {
    if (title.text.isEmpty) {
      showError(context, "Book title is required");
      return false;
    }
    if (procategory.text.isEmpty) {
      showError(context, "Product category is required");
      return false;
    }
    if (genre.text.isEmpty) {
      showError(context, "Genre is required");
      return false;
    }
    if (author.text.isEmpty) {
      showError(context, "Author is required");
      return false;
    }
    if (price.text.isEmpty) {
      showError(context, "Price is required");
      return false;
    }
    if (int.tryParse(price.text.trim()) == null) {
      showError(context, "Price must be a number");
      return false;
    }
    if (description.text.isEmpty) {
      showError(context, "Description is required");
      return false;
    }
    if (image.text.isEmpty) {
      showError(context, "Image URL is required");
      return false;
    }
    return true;
  }

  //For updateBook //
  bool _validateFieldsString(
    TextEditingController title,
    String procategory,
    TextEditingController genre,
    TextEditingController author,
    TextEditingController price,
    TextEditingController description,
    TextEditingController image,
    BuildContext context,
  ) {
    if (title.text.isEmpty) {
      showError(context, "Book title is required");
      return false;
    }
    if (procategory.isEmpty) {
      showError(context, "Product category is required");
      return false;
    }
    if (genre.text.isEmpty) {
      showError(context, "Genre is required");
      return false;
    }
    if (author.text.isEmpty) {
      showError(context, "Author is required");
      return false;
    }
    if (price.text.isEmpty) {
      showError(context, "Price is required");
      return false;
    }
    if (description.text.isEmpty) {
      showError(context, "Description is required");
      return false;
    }
    if (image.text.isEmpty) {
      showError(context, "Image URL is required");
      return false;
    }
    return true;
  }

  void _clearControllers(List<TextEditingController> controllers) {
    for (var controller in controllers) {
      controller.clear();
    }
  }

  void showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }
}
