// ignore_for_file: unused_local_variable, use_build_context_synchronously
import 'package:watchstore/Utils/App-Design.dart';
import 'package:watchstore/Widgets/appbar-user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class MyOrdersPage extends StatelessWidget {
  const MyOrdersPage({super.key});

  // 🔹 Function to return color based on status
  Color getStatusColor(String status) {
    switch (status) {
      case "Pending":
        return Colors.blue;
      case "Shipped":
        return Colors.orange;
      case "Delivered":
        return Colors.green;
      case "Cancelled":
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final String uid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: Appbarscreen(),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection("orders")
            .where("userid", isEqualTo: uid)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          var data = snapshot.data!.docs;
          if (data.isEmpty) {
            return const Center(child: Text("No Orders Found"));
          }

          return ListView.builder(
            itemCount: data.length,
            itemBuilder: (context, index) {
              var orderDoc = data[index];
              var order = orderDoc.data() as Map<String, dynamic>;
              String status = order["status"] ?? "Pending";

              return Card(
                margin: const EdgeInsets.all(10),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        order["name"] ?? "No Name",
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text("Quantity: ${order["orderquantity"] ?? 0}"),
                      Text("Email: ${order["email"] ?? "-"}"),
                      Text("Phone: ${order["phone"] ?? "-"}"),
                      Text("Address: ${order["address"] ?? "-"}"),
                      Text("City: ${order["city"] ?? "-"}"),
                      Text("Postal Code: ${order["postalcode"] ?? "-"}"),
                      Text("Payment Method: ${order["paymentMethod"] ?? "-"}"),
                      const SizedBox(height: 5),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("Status:"),
                          Text(
                            status,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: getStatusColor(status),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      if (status == "Pending" || status == "Shipped")
                        Align(
                          alignment: Alignment.centerRight,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppDesign.appHeadingColor,
                            ),
                            onPressed: () async {
                              bool confirm = await showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text("Cancel Order"),
                                  content: const Text(
                                    "Are you sure you want to cancel this order?",
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(context, false),
                                      child: const Text("No"),
                                    ),
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(context, true),
                                      child: const Text("Yes"),
                                    ),
                                  ],
                                ),
                              );

                              if (confirm) {
                                await FirebaseFirestore.instance
                                    .collection("orders")
                                    .doc(orderDoc.id)
                                    .update({"status": "Cancelled"});
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      "Order cancelled successfully",
                                    ),
                                  ),
                                );
                              }
                            },
                            child: const Text(
                              'Cancel Order',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontFamily: "Rubik",
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
