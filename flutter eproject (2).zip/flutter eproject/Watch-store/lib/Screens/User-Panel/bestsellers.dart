// ignore_for_file: avoid_print, deprecated_member_use, use_build_context_synchronously

import 'package:watchstore/Models/CartModel.dart';
import 'package:watchstore/Utils/App-Design.dart';
import 'package:watchstore/Screens/User-Panel/book-details.dart';
import 'package:watchstore/Screens/User-Panel/checkoutpage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:watchstore/Widgets/appbar-user.dart';
import 'package:watchstore/Widgets/bottomnavigation.dart';
import 'package:watchstore/Screens/User-Panel/home.dart';
import 'package:watchstore/Screens/User-Panel/arrival.dart';
import 'package:watchstore/Screens/User-Panel/contact.dart';
import 'package:watchstore/Screens/User-Panel/catalogPage.dart';

class BestsellersScreen extends StatefulWidget {
  const BestsellersScreen({super.key});

  @override
  State<BestsellersScreen> createState() => _BestsellersScreenState();
}

class _BestsellersScreenState extends State<BestsellersScreen> {
  final userid = FirebaseAuth.instance.currentUser!.uid;
  Set<String> wishlistIds = {}; // wishlist wale bookIds store karne ke liye

  @override
  void initState() {
    super.initState();
    _loadWishlist();
  }

  Future<void> _loadWishlist() async {
    final snapshot = await FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Wishlist")
        .get();

    setState(() {
      wishlistIds = snapshot.docs.map((doc) => doc.id).toSet();
    });
  }

  Future<void> toggleWishlist(Map<String, dynamic> book) async {
    final wishRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Wishlist")
        .doc(book["bookid"]);

    if (wishlistIds.contains(book["bookid"])) {
      await wishRef.delete();
      setState(() {
        wishlistIds.remove(book["bookid"]);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Removed from Wishlist")),
      );
    } else {
      await wishRef.set({
        "bookid": book["bookid"],
        "title": book["title"],
        "author": book["author"],
        "price": book["price"],
        "description": book["description"],
        "genre": book["genre"],
        "image": book["image"],
        "userid": userid,
        "addedAt": Timestamp.now(),
      });
      setState(() {
        wishlistIds.add(book["bookid"]);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Added to Wishlist")),
      );
    }
  }

  Future<List<Map<String, dynamic>>> fetchBestsellers() async {
    try {
      final ordersSnapshot = await FirebaseFirestore.instance
          .collection("orders")
          .get();

      Map<String, int> bookCounts = {};

      for (var doc in ordersSnapshot.docs) {
        final items = doc.data()["items"] as List<dynamic>? ?? [];
        for (var item in items) {
          final bookId = item["bookId"];
          if (bookId != null) {
            bookCounts[bookId] = (bookCounts[bookId] ?? 0) + 1;
          }
        }
      }

      if (bookCounts.isEmpty) {
        final booksSnapshot =
            await FirebaseFirestore.instance.collection("books").get();

        return booksSnapshot.docs.map((doc) {
          final data = doc.data();
          return {
            "bookid": doc.id,
            "title": data["title"] ?? "Unknown",
            "author": data["author"] ?? "Unknown",
            "price": data["price"] ?? 0,
            "image": data["image"] ?? "https://via.placeholder.com/150",
            "description": data["description"] ?? "",
            "genre": data["genre"] ?? "",
            "orders": 0,
          };
        }).toList();
      }

      final sortedBookIds = bookCounts.keys.toList()
        ..sort((a, b) => bookCounts[b]!.compareTo(bookCounts[a]!));

      List<Map<String, dynamic>> bestsellerBooks = [];

      for (var bookId in sortedBookIds) {
        final bookDoc = await FirebaseFirestore.instance
            .collection("books")
            .doc(bookId)
            .get();

        if (bookDoc.exists) {
          final data = bookDoc.data()!;
          bestsellerBooks.add({
            "bookid": bookDoc.id,
            "title": data["title"] ?? "Unknown",
            "author": data["author"] ?? "Unknown",
            "price": data["price"] ?? 0,
            "image": data["image"] ?? "https://via.placeholder.com/150",
            "description": data["description"] ?? "",
            "genre": data["genre"] ?? "",
            "orders": bookCounts[bookId],
          });
        }
      }

      return bestsellerBooks;
    } catch (e) {
      print("Error fetching bestsellers: $e");
      return [];
    }
  }

  Future<void> addToCart(CartItems items) async {
    final cartRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Cart")
        .doc(items.bookid);

    final cartItemSnp = await cartRef.get();

    if (cartItemSnp.exists) {
      cartRef.update({
        "bookquantity": FieldValue.increment(items.bookquantity),
      });
    } else {
      cartRef.set(items.toMap());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Appbarscreen(),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Bestsellers',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 54, 7, 240),
              ),
            ),
          ),

          // Bestseller Books Grid
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: fetchBestsellers(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text("No Bestsellers yet"));
                }

                final books = snapshot.data!;
                return GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 0.7,
                  ),
                  itemCount: books.length,
                  itemBuilder: (context, index) {
                    final book = books[index];
                    final isWishlisted = wishlistIds.contains(book["bookid"]);

                    return Stack(
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => BookDetails(
                                  bookid: book['bookid'],
                                  booktitle: book['title'],
                                  bookgenre: book['genre'],
                                  bookauthor: book['author'],
                                  bookprice: book['price'].toString(),
                                  bookdescription: book['description'],
                                  bookimage: book['image'],
                                ),
                              ),
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.3),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Rank
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    "#${index + 1} Bestseller",
                                    style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: AppDesign.appPrimaryColor,
                                    ),
                                  ),
                                ),
                                // Book Image
                                Container(
                                  height: 120,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    borderRadius: const BorderRadius.vertical(
                                      top: Radius.circular(12),
                                    ),
                                    image: DecorationImage(
                                      image: NetworkImage(book['image']),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                // Book Details
                                Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        book['title'],
                                        style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          height: 1.2,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        "by ${book['author']}",
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey[600],
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        "Rs. ${book['price']}",
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Color.fromARGB(
                                              255, 54, 7, 240),
                                        ),
                                      ),
                                      const SizedBox(height: 10),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          // Add to Cart
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Colors.purple,
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: IconButton(
                                              icon: const Icon(
                                                  Icons.add_shopping_cart,
                                                  size: 18),
                                              color: Colors.white,
                                              onPressed: () {
                                                addToCart(
                                                  CartItems(
                                                    bookid: book['bookid'],
                                                    userid: userid,
                                                    title: book['title'],
                                                    author: book['author'],
                                                    price: book['price']
                                                        .toString(),
                                                    description:
                                                        book['description'],
                                                    genre: book['genre'],
                                                    bookquantity: 1,
                                                  ),
                                                );
                                                ScaffoldMessenger.of(context)
                                                    .showSnackBar(
                                                  const SnackBar(
                                                    content: Text(
                                                        "Book added to Cart"),
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                          // Buy Now
                                          Container(
                                            decoration: BoxDecoration(
                                              color: const Color.fromARGB(
                                                  255, 39, 82, 176),
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: IconButton(
                                              icon: const Icon(Icons.shopping_bag,
                                                  size: 18),
                                              color: Colors.white,
                                              onPressed: () {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        CheckoutPage(
                                                      title: book['title'],
                                                      author: book['author'],
                                                      price: book['price']
                                                          .toString(),
                                                      image: book['image'],
                                                      description:
                                                          book['description'],
                                                      bookid: book['bookid'],
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        // Wishlist Icon
                        Positioned(
                          top: 8,
                          right: 8,
                          child: IconButton(
                            icon: Icon(
                              isWishlisted
                                  ? Icons.favorite
                                  : Icons.favorite_border,
                              color: isWishlisted ? Colors.red : Colors.grey,
                            ),
                            onPressed: () => toggleWishlist(book),
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: FooterNavigationBar(
        currentIndex: 1,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const Homescreen()),
              );
              break;
            case 1:
              break;
            case 2:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => const NewArrivalsScreen(),
                ),
              );
              break;
            case 3:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const ContactScreen()),
              );
              break;
            case 4:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => CatalogPage(categoryName: null),
                ),
              );
              break;
          }
        },
      ),
    );
  }
}
