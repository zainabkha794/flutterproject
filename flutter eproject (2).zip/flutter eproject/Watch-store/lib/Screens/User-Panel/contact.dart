// ignore_for_file: use_build_context_synchronously
import 'package:watchstore/Screens/User-Panel/arrival.dart';
import 'package:watchstore/Screens/User-Panel/bestsellers.dart';
import 'package:watchstore/Screens/User-Panel/catalogPage.dart';
import 'package:watchstore/Screens/User-Panel/home.dart';
import 'package:watchstore/Utils/App-Design.dart';
import 'package:watchstore/Widgets/bottomnavigation.dart';
import 'package:flutter/material.dart';

import '../../Widgets/appbar-user.dart';

class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});

  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: Appbarscreen(),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          children: [
            // Header Section
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 30),
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 54, 7, 240),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: Column(
                children: [
                  Icon(Icons.contact_support, size: 60, color: Colors.white),
                  SizedBox(height: 15),
                  Text(
                    'Contact Us',
                    style: TextStyle(
                      fontFamily: "Rubik",
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 30),

            // Contact Form
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 10,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                padding: EdgeInsets.all(20),
                child: Form(
                  child: Column(
                    children: [
                      Text(
                        'Send us a Message',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppDesign.appHeadingColor,
                        ),
                      ),
                      SizedBox(height: 20),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: "Your Name",
                          labelStyle: TextStyle(
                            color: AppDesign.appHeadingColor,
                          ),
                          prefixIcon: Icon(
                            Icons.person,
                            color: AppDesign.appPrimaryColor,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(
                              color: AppDesign.appHeadingColor,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(
                              color: AppDesign.appPrimaryColor,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      TextFormField(
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          labelText: "Your Email",
                          labelStyle: TextStyle(
                            color: AppDesign.appHeadingColor,
                          ),
                          prefixIcon: Icon(
                            Icons.email,
                            color: AppDesign.appPrimaryColor,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(
                              color: AppDesign.appHeadingColor,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(
                              color: AppDesign.appPrimaryColor,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      TextFormField(
                        maxLines: 5,
                        decoration: InputDecoration(
                          labelText: "Your Message",
                          labelStyle: TextStyle(
                            color: AppDesign.appHeadingColor,
                          ),
                          alignLabelWithHint: true,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(
                              color: AppDesign.appHeadingColor,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(
                              color: AppDesign.appPrimaryColor,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          minimumSize: Size(double.infinity, 50),
                          backgroundColor: AppDesign.appPrimaryColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        onPressed: () { },
                        child: Text(
                          'Send Message',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: "Rubik",
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 30),

            // Contact Information
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 10,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Contact Information',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppDesign.appHeadingColor,
                      ),
                    ),
                    SizedBox(height: 20),
                    _buildContactInfo(
                      Icons.location_on,
                      'Address',
                      'watchstore Near Urdu Bazar Jama',
                    ),
                    SizedBox(height: 15),
                    _buildContactInfo(
                      Icons.phone,
                      'Phone',
                      '03124534566',
                    ),
                    SizedBox(height: 15),
                    _buildContactInfo(
                      Icons.email,
                      'Email',
                      'www.watchstore.com.pk',
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 30),
          ],
        ),
      ),
      bottomNavigationBar: FooterNavigationBar(
        currentIndex: 3,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => Homescreen()),
              );
              break;
            case 1:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => BestsellersScreen()),
              );
              break;
            case 2:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => NewArrivalsScreen()),
              );
              break;
            case 3:
              // Already on contact screen
              break;
              case 4:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => CatalogPage(categoryName: null,)),
              );
              break;
          }
        },
      ),
    );
  }

  Widget _buildContactInfo(IconData icon, String title, String content) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: AppDesign.appPrimaryColor, size: 24),
        SizedBox(width: 15),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: AppDesign.appHeadingColor,
                ),
              ),
              SizedBox(height: 4),
              Text(content, style: TextStyle(color: Colors.grey[700])),
            ],
          ),
        ),
      ],
    );
  }
}
