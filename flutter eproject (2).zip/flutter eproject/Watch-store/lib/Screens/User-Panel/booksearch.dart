// ignore_for_file: unnecessary_cast, prefer_interpolation_to_compose_strings

import 'package:watchstore/Utils/App-Design.dart';
import 'package:watchstore/Widgets/bottomnavigation.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:watchstore/Widgets/appbar-user.dart';

import 'arrival.dart';
import 'bestsellers.dart';
import 'book-details.dart';
import 'catalogPage.dart';
import 'contact.dart';

class BookSearchPage extends StatefulWidget {
  final String query;
  const BookSearchPage({super.key, required this.query});

  @override
  State<BookSearchPage> createState() => _BookSearchPageState();
}

class _BookSearchPageState extends State<BookSearchPage> {
  final TextEditingController _searchController = TextEditingController();
  late Future<List<Map<String, dynamic>>> _searchFuture;
  int _selectedIndex = 0;

  Future<List<Map<String, dynamic>>> searchBooks(String query) async {
    if (query.isEmpty) return [];

    final firestore = FirebaseFirestore.instance;

    // 🔹 Title based search
    final titleResult = await firestore
        .collection("books")
        .where("title", isGreaterThanOrEqualTo: query)
        .where("title", isLessThan: query + 'z')
        .get();

    // 🔹 Category based search
    final categoryResult = await firestore
        .collection("books")
        .where("procategory", isGreaterThanOrEqualTo: query)
        .where("procategory", isLessThan: query + 'z')
        .get();

    // 🔹 Author based search
    final authorResult = await firestore
        .collection("books")
        .where("author", isGreaterThanOrEqualTo: query)
        .where("author", isLessThan: query + 'z')
        .get();

    // 🔹 Merge results (no duplicates)
    final allDocs = {
      ...titleResult.docs,
      ...categoryResult.docs,
      ...authorResult.docs,
    };

    return allDocs.map((doc) => doc.data() as Map<String, dynamic>).toList();
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => BestsellersScreen()),
        );
        break;
      case 2:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => NewArrivalsScreen()),
        );
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => ContactScreen()),
        );
        break;
      case 4:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => CatalogPage(categoryName: null),
          ),
        );
        break;
    }
  }

  @override
  void initState() {
    super.initState();
    _searchController.text = widget.query;
    _searchFuture = searchBooks(widget.query);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Appbarscreen(),
      body: Column(
        children: [
          SizedBox(height: 12),
          const Text(
            "Search Books",
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: AppDesign.appPrimaryColor,
            ),
          ),
          SizedBox(height: 12),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _searchFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (snapshot.hasError) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.error_outline,
                          size: 64,
                          color: Colors.red,
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'Something went wrong',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Error: ${snapshot.error}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.red),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: () {
                            setState(() {
                              _searchFuture = searchBooks(
                                _searchController.text,
                              );
                            });
                          },
                          child: const Text('Try Again'),
                        ),
                      ],
                    ),
                  );
                }

                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.search_off,
                          size: 64,
                          color: Colors.grey,
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'No books found',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Try searching for something else',
                          style: TextStyle(color: Colors.grey[600]),
                        ),
                      ],
                    ),
                  );
                }

                final books = snapshot.data!;

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 8),
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: books.length,
                        itemBuilder: (context, index) {
                          final data = books[index];
                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => BookDetails(
                                    bookid: data['bookid'],
                                    booktitle: data['title'],
                                    bookgenre: data['procategory'],
                                    bookauthor: data['author'],
                                    bookprice: data['price'].toString(),
                                    bookdescription: data['description'],
                                    bookimage: data['image'],
                                  ),
                                ),
                              );
                            },
                            child: Card(
                              margin: const EdgeInsets.only(bottom: 16),
                              elevation: 4,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Book cover
                                    Container(
                                      width: 80,
                                      height: 120,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        color: Colors.grey[200],
                                        image: data["image"] != null
                                            ? DecorationImage(
                                                image: NetworkImage(
                                                  data["image"],
                                                ),
                                                fit: BoxFit.cover,
                                              )
                                            : null,
                                      ),
                                      child: data["image"] == null
                                          ? const Icon(
                                              Icons.book,
                                              size: 40,
                                              color: Colors.blueGrey,
                                            )
                                          : null,
                                    ),
                                    const SizedBox(width: 16),
                                    // Book details
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            data["title"] ?? "Unknown Title",
                                            style: const TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            "by ${data["author"] ?? "Unknown Author"}",
                                            style: TextStyle(
                                              fontSize: 14,
                                              color: Colors.grey[600],
                                            ),
                                          ),
                                          const SizedBox(height: 8),
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 8,
                                              vertical: 4,
                                            ),
                                            decoration: BoxDecoration(
                                              color: Colors.blueGrey[50],
                                              borderRadius:
                                                  BorderRadius.circular(4),
                                            ),
                                            child: Text(
                                              data["procategory"] ??
                                                  "Uncategorized",
                                              style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.blueGrey[800],
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: FooterNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
