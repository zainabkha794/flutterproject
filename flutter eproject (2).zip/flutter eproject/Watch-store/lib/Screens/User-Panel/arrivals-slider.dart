// ignore_for_file: deprecated_member_use

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../Models/CartModel.dart';
import 'book-details.dart';
import 'checkoutpage.dart';

class NewArrivals extends StatefulWidget {
  final String bookid;
  final String booktitle;
  final String bookgenre;
  final String bookauthor;
  final String bookprice;
  final String bookdescription;
  final String bookimage;

  const NewArrivals({
    super.key,
    required this.bookid,
    required this.booktitle,
    required this.bookgenre,
    required this.bookauthor,
    required this.bookprice,
    required this.bookdescription,
    required this.bookimage,
  });

  @override
  State<NewArrivals> createState() => _NewArrivalsState();
}

class _NewArrivalsState extends State<NewArrivals> {
  bool isWishlisted = false;

  @override
  void initState() {
    super.initState();
    _checkIfWishlisted();
  }

  Future<void> _checkIfWishlisted() async {
    final userid = FirebaseAuth.instance.currentUser!.uid;
    final wishRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Wishlist")
        .doc(widget.bookid);

    final snapshot = await wishRef.get();
    if (snapshot.exists) {
      setState(() {
        isWishlisted = true;
      });
    }
  }

  Future<void> toggleWishlist() async {
    final userid = FirebaseAuth.instance.currentUser!.uid;
    final wishRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Wishlist")
        .doc(widget.bookid);

    final snapshot = await wishRef.get();

    if (snapshot.exists) {
      await wishRef.delete();
      setState(() {
        isWishlisted = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Removed from Wishlist")),
      );
    } else {
      await wishRef.set({
        "bookid": widget.bookid,
        "userid": userid,
        "title": widget.booktitle,
        "author": widget.bookauthor,
        "price": widget.bookprice,
        "description": widget.bookdescription,
        "genre": widget.bookgenre,
        "image": widget.bookimage,
        "addedAt": Timestamp.now(),
      });
      setState(() {
        isWishlisted = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Added to Wishlist")),
      );
    }
  }

  Future<void> addToCart(CartItems items) async {
    final userid = FirebaseAuth.instance.currentUser!.uid;

    final cartRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Cart")
        .doc(items.bookid);

    final cartItemSnp = await cartRef.get();

    if (cartItemSnp.exists) {
      cartRef.update({
        "bookquantity": FieldValue.increment(items.bookquantity),
      });
    } else {
      cartRef.set(items.toMap());
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BookDetails(
              bookid: widget.bookid,
              booktitle: widget.booktitle,
              bookgenre: widget.bookgenre,
              bookauthor: widget.bookauthor,
              bookprice: widget.bookprice,
              bookdescription: widget.bookdescription,
              bookimage: widget.bookimage,
            ),
          ),
        );
      },
      child: Container(
        width: 200,
        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          children: [
            // Book Image with Wishlist Icon
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(12),
                    topRight: Radius.circular(12),
                  ),
                  child: Image.network(
                    widget.bookimage,
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      height: 180,
                      width: double.infinity,
                      color: Colors.grey[200],
                      child: const Icon(Icons.book,
                          size: 40, color: Colors.grey),
                    ),
                  ),
                ),
                Positioned(
                  right: 8,
                  top: 8,
                  child: IconButton(
                    icon: Icon(
                      isWishlisted
                          ? Icons.favorite
                          : Icons.favorite_border,
                      color: isWishlisted ? Colors.red : Colors.grey,
                      size: 28,
                    ),
                    onPressed: toggleWishlist,
                  ),
                ),
              ],
            ),

            // Book Details
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  // watch title
                  Text(
                    widget.booktitle,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      height: 1.2,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),

                  const SizedBox(height: 4),

                  // Book Author
                  Text(
                    widget.bookauthor,
                    style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),

                  const SizedBox(height: 6),

                  // Genre Tag
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    child: Text(
                      widget.bookgenre,
                      style: const TextStyle(
                        fontSize: 10,
                        color: Colors.purple,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),

                  const SizedBox(height: 8),

                  // Price and Add to Cart Button
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Rs. ${widget.bookprice}",
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.purple,
                        ),
                      ),

                      // Add to Cart Button
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.purple,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.add_shopping_cart, size: 18),
                          color: Colors.white,
                          onPressed: () {
                            final userid =
                                FirebaseAuth.instance.currentUser!.uid;
                            addToCart(
                              CartItems(
                                bookid: widget.bookid,
                                userid: userid,
                                title: widget.booktitle,
                                author: widget.bookauthor,
                                price: widget.bookprice,
                                description: widget.bookdescription,
                                genre: widget.bookgenre,
                                bookquantity: 1,
                              ),
                            );
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Book added to Cart"),
                              ),
                            );
                          },
                        ),
                      ),

                      Container(
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 39, 82, 176),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.shopping_bag, size: 18),
                          color: Colors.white,
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => CheckoutPage(
                                  bookid: widget.bookid,
                                  title: widget.booktitle,
                                  author: widget.bookauthor,
                                  price: widget.bookprice,
                                  image: widget.bookimage,
                                  description: widget.bookdescription,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
