// ignore_for_file: use_build_context_synchronously, unnecessary_brace_in_string_interps, deprecated_member_use

import 'package:watchstore/Models/CartModel.dart';
import 'package:watchstore/Models/ReviewModel.dart';
import 'package:watchstore/Widgets/appbar-user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../Utils/App-Design.dart';
import 'checkoutpage.dart';

class BookDetails extends StatefulWidget {
  final String bookid;
  final String booktitle;
  final String bookgenre;
  final String bookauthor;
  final String bookprice;
  final String bookdescription;
  final String bookimage;

  const BookDetails({
    super.key,
    required this.bookid,
    required this.booktitle,
    required this.bookgenre,
    required this.bookauthor,
    required this.bookprice,
    required this.bookdescription,
    required this.bookimage,
  });

  Future<void> addToCart(CartItems items) async {
    final userid = FirebaseAuth.instance.currentUser!.uid;

    final cartRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Cart")
        .doc(items.bookid);

    final cartItemSnp = await cartRef.get();

    if (cartItemSnp.exists) {
      cartRef.update({
        "bookquantity": FieldValue.increment(items.bookquantity),
      });
    } else {
      cartRef.set(items.toMap());
    }
  }

  @override
  State<BookDetails> createState() => _BookDetailsState();
}

class _BookDetailsState extends State<BookDetails> {
  int _rating = 0;
  String? _selectedStatus;

  Future<void> _submitReview() async {
    if (_rating == 0 || _selectedStatus == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select rating and status!")),
      );
      return;
    }

    final userid = FirebaseAuth.instance.currentUser!.uid;

    final review = ReviewModel(
      id: "",
      userid: userid,
      bookid: widget.bookid,
      rating: _rating,
      status: _selectedStatus!,
      createdAt: Timestamp.now(),
    );

    await FirebaseFirestore.instance
        .collection("books")
        .doc(widget.bookid)
        .collection("reviews")
        .add(review.toMap());

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Review submitted successfully!")),
    );

    setState(() {
      _rating = 0;
      _selectedStatus = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Appbarscreen(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 20),
                height: 300,
                width: MediaQuery.of(context).size.width * 0.7,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 3,
                      blurRadius: 7,
                      offset: const Offset(0, 3),
                    ),
                  ],
                  image: DecorationImage(
                    image: NetworkImage(widget.bookimage),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),

            // Book Details Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.booktitle,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 54, 7, 240),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "by ${widget.bookauthor}",
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.grey[700],
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                  const SizedBox(height: 15),

                  // Updated StreamBuilder to show review count and average rating
                  StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection("books")
                        .doc(widget.bookid)
                        .collection("reviews")
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      final reviews = snapshot.data!.docs;
                      final reviewCount = reviews.length;

                      if (reviewCount == 0) {
                        return const Text(
                          "No reviews yet.",
                          style: TextStyle(fontSize: 16),
                        );
                      }

                      double totalRating = 0;
                      for (var doc in reviews) {
                        totalRating += double.parse(doc['rating'].toString());
                      }

                      final averageRating = totalRating / reviewCount;

                      return Row(
                        children: [
                          const Icon(Icons.star, color: Colors.amber),
                          const SizedBox(width: 4),
                          Text(
                            averageRating.toStringAsFixed(1),
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            "($reviewCount reviews)",
                            style: const TextStyle(
                              fontSize: 16,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      );
                    },
                  ),

                  // Price Section
                  const SizedBox(height: 20),
                  Text(
                    "Price: ${widget.bookprice}",
                    style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 30, 169, 13),
                    ),
                  ),
                  const SizedBox(height: 20),

                  const Divider(thickness: 1, color: Colors.grey),
                  const SizedBox(height: 15),

                  // Description
                  Text(
                    "Description:",
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 54, 7, 240),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.bookdescription,
                    style: const TextStyle(fontSize: 16, height: 1.5),
                    textAlign: TextAlign.justify,
                  ),
                  const SizedBox(height: 40),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                                final userid = FirebaseAuth.instance.currentUser!.uid;
                            widget.addToCart(
                              
                              CartItems(
                                userid: userid,
                                bookid: widget.bookid,
                                title: widget.booktitle,
                                author: widget.bookauthor,
                                price: widget.bookprice,
                                description: widget.bookdescription,
                                genre: widget.bookgenre,
                                bookquantity: 1,
                              ),
                            );
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Book added to Cart "),
                              ),
                            );
                          },
                          icon: const Icon(
                            Icons.shopping_cart_outlined,
                            color: Colors.white,
                          ),
                          label: const Text(
                            "Add to Cart",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppDesign.appPrimaryColor,
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            elevation: 5,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => CheckoutPage(
                                  title: widget.booktitle,
                                  author: widget.bookauthor,
                                  price: widget.bookprice,
                                  image: widget.bookimage,
                                  description: widget.bookdescription,
                                   bookid: widget.bookid,
                                ),
                              ),
                            );
                          },
                          icon: const Icon(
                            Icons.shopping_bag_outlined,
                            color: Colors.white,
                          ),
                          label: const Text(
                            "Buy Now",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppDesign.appHeadingColor,
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            elevation: 5,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),
                  const Divider(thickness: 1, color: Colors.grey),
                  const SizedBox(height: 15),

                  // Give Your Review Section (Fixed Layout)
                  const Text(
                    "Give Your Review:",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 54, 7, 240),
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Rating (Stars)
                  Row(
                    children: List.generate(5, (index) {
                      return IconButton(
                        onPressed: () {
                          setState(() {
                            _rating = index + 1;
                          });
                        },
                        icon: Icon(
                          Icons.star,
                          color: (index < _rating) ? Colors.amber : Colors.grey,
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 10),

                  // Dropdown for Review Status
                  DropdownButton<String>(
                    hint: const Text("Select Review Type"),
                    value: _selectedStatus,
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedStatus = newValue;
                      });
                    },
                    items: <String>['Good', 'Bad', 'Average']
                        .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        })
                        .toList(),
                  ),
                  const SizedBox(height: 15),

                  // Submit Button
                  ElevatedButton(
                    onPressed: _submitReview,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: const EdgeInsets.symmetric(
                        vertical: 12,
                        horizontal: 20,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: const Text(
                      "Submit Review",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
