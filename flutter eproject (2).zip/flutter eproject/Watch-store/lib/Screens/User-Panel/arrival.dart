// ignore_for_file: avoid_print

import 'package:watchstore/Screens/User-Panel/bestsellers.dart';
import 'package:watchstore/Screens/User-Panel/catalogPage.dart';
import 'package:watchstore/Screens/User-Panel/contact.dart';
import 'package:watchstore/Screens/User-Panel/home.dart';
import 'package:watchstore/Widgets/appbar-user.dart';
import 'package:watchstore/Widgets/bottomnavigation.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:watchstore/Models/CartModel.dart';
import 'package:watchstore/Screens/User-Panel/book-details.dart';
import 'package:watchstore/Screens/User-Panel/checkoutpage.dart';

class NewArrivalsScreen extends StatefulWidget {
  const NewArrivalsScreen({super.key});

  @override
  State<NewArrivalsScreen> createState() => _NewArrivalsScreenState();
}

class _NewArrivalsScreenState extends State<NewArrivalsScreen> {
  // Track wishlist states locally
  final Map<String, bool> wishlistStates = {};

  Future<void> addToCart(CartItems items) async {
    final userid = FirebaseAuth.instance.currentUser!.uid;

    final cartRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Cart")
        .doc(items.bookid);

    final cartItemSnp = await cartRef.get();

    if (cartItemSnp.exists) {
      cartRef.update({
        "bookquantity": FieldValue.increment(items.bookquantity),
      });
    } else {
      cartRef.set(items.toMap());
    }
  }

  Future<List<Map<String, dynamic>>> fetchNewArrivals() async {
    try {
      final booksSnapshot = await FirebaseFirestore.instance
          .collection("books")
          .orderBy("createdAt", descending: true)
          .limit(10)
          .get();

      return booksSnapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'bookid': doc.id,
          'title': data['title'] ?? 'Unknown',
          'price': data['price'] ?? 0,
          'image': data['image'] ?? 'https://via.placeholder.com/150',
          'author': data['author'] ?? 'Unknown',
          'description': data['description'] ?? '',
          'genre': data['genre'] ?? '',
          'rating': data['rating'] ?? 0,
          'reviews': data['reviews'] ?? 0,
          'isNew': true,
        };
      }).toList();
    } catch (e) {
      print("Error fetching new arrivals: $e");
      return [];
    }
  }

  Future<void> toggleWishlist(Map<String, dynamic> book) async {
    final userid = FirebaseAuth.instance.currentUser!.uid;
    final wishRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Wishlist")
        .doc(book['bookid']);

    final snapshot = await wishRef.get();

    if (snapshot.exists) {
      await wishRef.delete();
      setState(() {
        wishlistStates[book['bookid']] = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Removed from Wishlist")),
      );
    } else {
      await wishRef.set({
        "bookid": book['bookid'],
        "userid": userid,
        "title": book['title'],
        "author": book['author'],
        "price": book['price'].toString(),
        "description": book['description'],
        "genre": book['genre'],
        "image": book['image'],
        "addedAt": Timestamp.now(),
      });
      setState(() {
        wishlistStates[book['bookid']] = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Added to Wishlist")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final userid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: Appbarscreen(),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'New Arrivals',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 54, 7, 240),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Discover the latest watch collection',
                  style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                ),
              ],
            ),
          ),
          // New Arrivals Grid
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: fetchNewArrivals(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text("No new arrivals yet."));
                }

                final newArrivalBooks = snapshot.data!;

                return GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 0.7,
                  ),
                  itemCount: newArrivalBooks.length,
                  itemBuilder: (context, index) {
                    final book = newArrivalBooks[index];
                    final isWishlisted = wishlistStates[book['bookid']] ?? false;

                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BookDetails(
                              bookid: book['bookid'],
                              booktitle: book['title'],
                              bookgenre: book['genre'],
                              bookauthor: book['author'],
                              bookprice: book['price'].toString(),
                              bookdescription: book['description'],
                              bookimage: book['image'],
                            ),
                          ),
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.3),
                              blurRadius: 10,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Book Image
                                Container(
                                  height: 120,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    borderRadius: const BorderRadius.vertical(
                                      top: Radius.circular(12),
                                    ),
                                    image: DecorationImage(
                                      image: NetworkImage(book['image']),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),

                                // Book Details
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              book['title'],
                                              style: const TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                                height: 1.2,
                                              ),
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              'by ${book['author']}',
                                              style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey[600],
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ),

                                        // Price and Buttons
                                        Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  'Rs. ${book['price']}',
                                                  style: const TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold,
                                                    color: Color.fromARGB(
                                                        255, 54, 7, 240),
                                                  ),
                                                ),
                                                // Add to Cart Button
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: Colors.purple,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ),
                                                  child: IconButton(
                                                    icon: const Icon(
                                                        Icons.add_shopping_cart,
                                                        size: 18),
                                                    color: Colors.white,
                                                    onPressed: () {
                                                      addToCart(
                                                        CartItems(
                                                          bookid:
                                                              book['bookid'],
                                                          userid: userid,
                                                          title: book['title'],
                                                          author:
                                                              book['author'],
                                                          price: book['price']
                                                              .toString(),
                                                          description:
                                                              book['description'],
                                                          genre: book['genre'],
                                                          bookquantity: 1,
                                                        ),
                                                      );
                                                      ScaffoldMessenger.of(
                                                              context)
                                                          .showSnackBar(
                                                        const SnackBar(
                                                          content: Text(
                                                              "Book added to Cart"),
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(height: 8),
                                            SizedBox(
                                              width: double.infinity,
                                              child: ElevatedButton(
                                                onPressed: () {
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                      builder: (context) =>
                                                          CheckoutPage(
                                                        title: book['title'],
                                                        author: book['author'],
                                                        price: book['price']
                                                            .toString(),
                                                        image: book['image'],
                                                        description:
                                                            book['description'],
                                                        bookid: book['bookid'],
                                                      ),
                                                    ),
                                                  );
                                                },
                                                style: ElevatedButton.styleFrom(
                                                  backgroundColor:
                                                      const Color.fromARGB(
                                                          255, 39, 82, 176),
                                                  foregroundColor: Colors.white,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8),
                                                  ),
                                                ),
                                                child: const Text('Buy Now'),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            // Wishlist Icon ❤️
                            Positioned(
                              top: 8,
                              right: 8,
                              child: IconButton(
                                icon: Icon(
                                  isWishlisted
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  color:
                                      isWishlisted ? Colors.red : Colors.grey,
                                ),
                                onPressed: () => toggleWishlist(book),
                              ),
                            ),

                            // New Badge
                            if (book['isNew'] == true)
                              Positioned(
                                top: 8,
                                left: 8,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.green,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: const Text(
                                    'NEW',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: FooterNavigationBar(
        currentIndex: 2,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const Homescreen()),
              );
              break;
            case 1:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => const BestsellersScreen()),
              );
              break;
            case 2:
              break;
            case 3:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const ContactScreen()),
              );
              break;
            case 4:
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => CatalogPage(categoryName: null)),
              );
              break;
          }
        },
      ),
    );
  }
}
