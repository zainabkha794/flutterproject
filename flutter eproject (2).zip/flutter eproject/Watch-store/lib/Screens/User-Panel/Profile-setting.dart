// ignore_for_file: avoid_print, use_build_context_synchronously
import 'package:watchstore/Models/UserModel.dart';
import 'package:watchstore/Screens/User-Panel/home.dart';
import 'package:watchstore/Screens/User-Panel/myorder.dart';
import 'package:watchstore/Utils/App-Design.dart';
import 'package:watchstore/Widgets/appbar-user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Profilesetting extends StatefulWidget {
  const Profilesetting({super.key});

  @override
  State<Profilesetting> createState() => _ProfilesettingState();
}

class _ProfilesettingState extends State<Profilesetting> {
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController imageController = TextEditingController();

  Usermodel? usermodel;
  bool isLoading = true;

  Future getCurrentUser() async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection("users")
          .doc(FirebaseAuth.instance.currentUser?.uid)
          .get();

      if (doc.exists) {
        setState(() {
          usermodel = Usermodel.fromDocument(doc);
          isLoading = false;
          name.text = usermodel!.Name;
          email.text = usermodel!.email;
          imageController.text = usermodel?.image ?? "";
        });
      } else {
        print("User not found");
      }
    } catch (e) {
      print("Firebase error: $e");
    }
  }

  @override
  void initState() {
    super.initState();
    getCurrentUser();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading == true) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(AppDesign.appPrimaryColor),
          ),
        ),
      );
    }
    return Scaffold(
      appBar: Appbarscreen(),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              Text(
                'Profile',
                style: TextStyle(
                  color: AppDesign.appHeadingColor,
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 30),

              // Profile Image
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppDesign.appSecondaryColor,
                    width: 3,
                  ),
                ),
                child: CircleAvatar(
                  radius: 70,
                  backgroundImage:
                      (usermodel?.image != null && usermodel!.image.isNotEmpty)
                          ? NetworkImage(usermodel!.image)
                          : const AssetImage("assets/images/image.jpeg")
                              as ImageProvider,
                ),
              ),

              const SizedBox(height: 30),

              // Name
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.only(left: 8.0, bottom: 8.0),
                  child: Text(
                    "Name",
                    style: TextStyle(
                      color: AppDesign.appHeadingColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
              TextFormField(
                controller: name,
                decoration: InputDecoration(
                  hintText: usermodel?.Name ?? "Unknown User",
                  labelStyle: TextStyle(color: AppDesign.appHeadingColor),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(color: AppDesign.appSecondaryColor),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(
                      color: AppDesign.appSecondaryColor,
                      width: 2,
                    ),
                  ),
                  prefixIcon: Icon(
                    Icons.person,
                    color: AppDesign.appSecondaryColor,
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 20,
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Email
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.only(left: 8.0, bottom: 8.0),
                  child: Text(
                    "Email",
                    style: TextStyle(
                      color: AppDesign.appHeadingColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
              TextFormField(
                controller: email,
                enabled: false,
                decoration: InputDecoration(
                  hintText: usermodel?.email ?? "Unknown Email",
                  labelStyle: TextStyle(color: AppDesign.appHeadingColor),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(color: AppDesign.appSecondaryColor),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(
                      color: AppDesign.appSecondaryColor,
                      width: 2,
                    ),
                  ),
                  prefixIcon: Icon(
                    Icons.email,
                    color: AppDesign.appSecondaryColor,
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 20,
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Image URL Field
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.only(left: 8.0, bottom: 8.0),
                  child: Text(
                    "Profile Image",
                    style: TextStyle(
                      color: AppDesign.appHeadingColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
              TextFormField(
                controller: imageController,
                decoration: InputDecoration(
                  hintText: "Enter Image URL",
                  labelStyle: TextStyle(color: AppDesign.appHeadingColor),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(color: AppDesign.appSecondaryColor),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(
                      color: AppDesign.appSecondaryColor,
                      width: 2,
                    ),
                  ),
                  prefixIcon: Icon(
                    Icons.image,
                    color: AppDesign.appSecondaryColor,
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 20,
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // Update Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    updateUserData();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppDesign.appPrimaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    elevation: 3,
                  ),
                  child: const Text(
                    'Update Profile',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),

              const SizedBox(height: 15),
              
              // Check Order Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyOrdersPage()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppDesign.appSecondaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    elevation: 3,
                  ),
                  child: const Text(
                    'Check My Orders',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future updateUserData() async {
    String uid = FirebaseAuth.instance.currentUser!.uid;

    FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .update({
          'Name': name.text,
          'email': email.text,
          'image': imageController.text,
        })
        .then((_) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Profile Updated Successfully'),
              backgroundColor: Colors.green,
            ),
          );
          Future.delayed(const Duration(seconds: 2), () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => Homescreen()),
              (route) => false,
            );
          });
        })
        .catchError((error) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error updating profile: $error'),
              backgroundColor: Colors.red,
            ),
          );
        });
  }
}