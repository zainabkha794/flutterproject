import 'package:flutter/material.dart';

class Categories extends StatelessWidget {
  final String categoryName;
  final String categoryImage;

  const Categories({
    super.key,
    required this.categoryName,
    required this.categoryImage,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      width: 150,
      margin: EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: NetworkImage(categoryImage),
          fit: BoxFit.cover,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Color.fromARGB(36, 0, 0, 0),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Center(
          child: Text(
            categoryName,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
