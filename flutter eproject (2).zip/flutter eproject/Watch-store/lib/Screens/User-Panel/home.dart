// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:watchstore/Screens/User-Panel/arrival.dart';
import 'package:watchstore/Screens/User-Panel/arrivals-slider.dart';
import 'package:watchstore/Screens/User-Panel/bestsellers-slider.dart';
import 'package:watchstore/Screens/User-Panel/bestsellers.dart';
import 'package:watchstore/Screens/User-Panel/catalogPage.dart';
import 'package:watchstore/Screens/User-Panel/contact.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../Utils/App-Design.dart';
import '../../Widgets/appbar-user.dart';
import '../../Widgets/bottomnavigation.dart';

import 'booksearch.dart';
import 'custom-slider.dart';

class Homescreen extends StatefulWidget {
  const Homescreen({super.key});

  @override
  State<Homescreen> createState() => _HomescreenState();
}

class _HomescreenState extends State<Homescreen> {
  final TextEditingController searchController = TextEditingController();
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => BestsellersScreen()),
        );
        break;
      case 2:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => NewArrivalsScreen()),
        );
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => ContactScreen()),
        );
        break;
      case 4:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => CatalogPage(categoryName: null),
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Appbarscreen(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Search Bar
            Container(
              padding: const EdgeInsets.all(16),
              color: Colors.white,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: TextField(
                        controller: searchController,
                        decoration: const InputDecoration(
                          hintText: "Search for watches...",
                          border: InputBorder.none,
                          prefixIcon: Icon(Icons.search, color: Colors.grey),
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 15,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    decoration: BoxDecoration(
                      color: AppDesign.appPrimaryColor,
                      shape: BoxShape.circle,
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.search, color: Colors.white),
                      onPressed: () {
                        final query = searchController.text.trim();

                        if (query.isEmpty) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text("Please enter something to search"),
                              backgroundColor: Colors.redAccent,
                            ),
                          );
                          return;
                        }
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BookSearchPage(query: query),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            //customslider//
            StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection("slider")
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(20),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(20),
                    child: Center(child: Text("No slider images found.")),
                  );
                }
                final sliderImages = snapshot.data!.docs
                    .map((doc) => doc["image"].toString())
                    .toList();
                final sliderData = snapshot.data!.docs
                    .map(
                      (doc) => {
                        'name': doc["name"].toString(),
                        'image': doc["image"].toString(),
                      },
                    )
                    .toList();

                return CustomImageSlider(
                  sliderImages: sliderImages,
                  sliderData: sliderData,
                );
              },
            ),
            // Best Sellers
            const SizedBox(height: 24),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Best Sellers",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppDesign.appPrimaryColor,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection("books")
                  .orderBy("createdAt", descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Center(child: Text("No books found.")),
                  );
                }

                final bookDocs = snapshot.data!.docs;

                return GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, // 2 cards per row
                    childAspectRatio:
                        0.65, // Adjusted for your Bestsellers widget
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: bookDocs.length,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemBuilder: (context, index) {
                    final doc = bookDocs[index];
                    return Bestsellers(
                      bookid: doc["bookid"],
                      booktitle: doc["title"],
                      bookgenre: doc["genre"],
                      bookauthor: doc["author"],
                      bookprice: doc["price"].toString(),
                      bookdescription: doc["description"],
                      bookimage: doc["image"],
                    );
                  },
                );
              },
            ),

            // New Arrivals
            const SizedBox(height: 24),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "New Arrivals",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppDesign.appPrimaryColor,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection("books")
                  .orderBy("createdAt", descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Center(child: Text("No books found.")),
                  );
                }

                final bookDocs = snapshot.data!.docs;

                return GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, // 2 cards per row
                    childAspectRatio:
                        0.65, // Adjusted for your Bestsellers widget
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: bookDocs.length,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemBuilder: (context, index) {
                    final doc = bookDocs[index];
                    return NewArrivals(
                      bookid: doc["bookid"],
                      booktitle: doc["title"],
                      bookgenre: doc["genre"],
                      bookauthor: doc["author"],
                      bookprice: doc["price"].toString(),
                      bookdescription: doc["description"],
                      bookimage: doc["image"],
                    );
                  },
                );
              },
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),

      // Bottom Navigation Bar
      bottomNavigationBar: FooterNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
