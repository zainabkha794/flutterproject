// ignore_for_file: deprecated_member_use, use_build_context_synchronously
import 'package:watchstore/Models/CartModel.dart';
import 'package:watchstore/Screens/User-Panel/book-details.dart';
import 'package:watchstore/Screens/User-Panel/contact.dart';
import 'package:watchstore/Screens/User-Panel/home.dart';
import 'package:watchstore/Utils/App-Design.dart';
import 'package:watchstore/Widgets/appbar-user.dart';
import 'package:watchstore/Widgets/bottomnavigation.dart';
import 'package:firebase_auth/firebase_auth.dart' show FirebaseAuth;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'arrival.dart';
import 'bestsellers.dart';
import 'checkoutpage.dart';

class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key, required categoryName});

  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  String? selectedCategory;
  String selectedFilter = "All";
  int _selectedIndex = 4;
  Set<String> wishlistIds = {};
  final userid = FirebaseAuth.instance.currentUser!.uid;

  @override
  void initState() {
    super.initState();
    _loadWishlist();
  }

  Future<void> _loadWishlist() async {
    final snapshot = await FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Wishlist")
        .get();

    setState(() {
      wishlistIds = snapshot.docs.map((doc) => doc.id).toSet();
    });
  }

  Future<void> toggleWishlist(Map<String, dynamic> book) async {
    final wishRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Wishlist")
        .doc(book["bookid"]);

    if (wishlistIds.contains(book["bookid"])) {
      await wishRef.delete();
      setState(() {
        wishlistIds.remove(book["bookid"]);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Removed from Wishlist")),
      );
    } else {
      await wishRef.set({
        "bookid": book["bookid"],
        "title": book["title"],
        "author": book["author"],
        "price": book["price"],
        "description": book["description"],
        "genre": book["procategory"],
        "image": book["image"],
        "userid": userid,
        "addedAt": Timestamp.now(),
      });
      setState(() {
        wishlistIds.add(book["bookid"]);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Added to Wishlist")),
      );
    }
  }

  Future<void> addToCart(CartItems items) async {
    final cartRef = FirebaseFirestore.instance
        .collection("users")
        .doc(userid)
        .collection("Cart")
        .doc(items.bookid);

    final cartItemSnp = await cartRef.get();

    if (cartItemSnp.exists) {
      cartRef.update({
        "bookquantity": FieldValue.increment(items.bookquantity),
      });
    } else {
      cartRef.set(items.toMap());
    }
  }

  void _onItemTapped(int index) {
    if (_selectedIndex == index) return;
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => Homescreen()),
        );
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => BestsellersScreen()),
        );
        break;
      case 2:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => NewArrivalsScreen()),
        );
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => ContactScreen()),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: Appbarscreen(),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Catalog",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: AppDesign.appPrimaryColor,
                  ),
                ),
                DropdownButton<String>(
                  value: selectedFilter,
                  items: const [
                    DropdownMenuItem(value: "All", child: Text("All")),
                    DropdownMenuItem(
                      value: "LowToHigh",
                      child: Text("Price: Low → High"),
                    ),
                    DropdownMenuItem(
                      value: "HighToLow",
                      child: Text("Price: High → Low"),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() {
                      selectedFilter = value!;
                    });
                  },
                ),
              ],
            ),
          ),

          // 🔹 Categories Section
          SizedBox(
            height: 120,
            child: StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection("categories")
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final categories = snapshot.data!.docs;

                return ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 12,
                  ),
                  itemCount: categories.length,
                  itemBuilder: (context, index) {
                    final category = categories[index];
                    final catName = category["name"];
                    final hasImage =
                        category.data().containsKey("image") &&
                        category["image"] != null &&
                        category["image"].toString().isNotEmpty;
                    final isSelected = selectedCategory == catName;

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedCategory = catName;
                        });
                      },
                      child: Container(
                        width: 90,
                        margin: const EdgeInsets.symmetric(horizontal: 8),
                        child: Column(
                          children: [
                            Container(
                              width: 70,
                              height: 70,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.grey[100],
                                border: isSelected
                                    ? Border.all(color: Colors.blue, width: 3)
                                    : Border.all(
                                        color: Colors.grey[300]!,
                                        width: 2,
                                      ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.3),
                                    blurRadius: 6,
                                    offset: const Offset(0, 3),
                                  ),
                                ],
                              ),
                              child: ClipOval(
                                child: hasImage
                                    ? Image.network(
                                        category["image"],
                                        fit: BoxFit.cover,
                                        errorBuilder:
                                            (context, error, stackTrace) {
                                              return const Icon(
                                                Icons.category,
                                                size: 30,
                                                color: Colors.grey,
                                              );
                                            },
                                      )
                                    : const Icon(
                                        Icons.category,
                                        size: 30,
                                        color: Colors.grey,
                                      ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              catName,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: isSelected ? Colors.blue : Colors.black,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),

          // 🔹 Books Grid (with filter)
          Expanded(
            child: Container(
              color: Colors.grey[50],
              child: StreamBuilder(
                stream: (selectedCategory == null)
                    ? FirebaseFirestore.instance.collection("books").snapshots()
                    : FirebaseFirestore.instance
                          .collection("books")
                          .where("procategory", isEqualTo: selectedCategory)
                          .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text("No books found"));
                  }

                  var bookDocs = snapshot.data!.docs;

                  // 🔹 Apply Sorting based on filter
                  if (selectedFilter == "LowToHigh") {
                    bookDocs.sort(
                      (a, b) =>
                          (a["price"] as num).compareTo(b["price"] as num),
                    );
                  } else if (selectedFilter == "HighToLow") {
                    bookDocs.sort(
                      (a, b) =>
                          (b["price"] as num).compareTo(a["price"] as num),
                    );
                  }

                  return GridView.builder(
                    padding: const EdgeInsets.all(16),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 16,
                          mainAxisSpacing: 16,
                          childAspectRatio: 0.75,
                        ),
                    itemCount: bookDocs.length,
                    itemBuilder: (context, index) {
                      final doc = bookDocs[index];
                      final hasImage =
                          doc.data().containsKey("image") &&
                          doc["image"] != null &&
                          doc["image"].toString().isNotEmpty;
                      final isWishlisted = wishlistIds.contains(doc["bookid"]);

                      return Stack(
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => BookDetails(
                                    bookid: doc["bookid"],
                                    booktitle: doc["title"] ?? "No Title",
                                    bookgenre: doc["procategory"] ?? "",
                                    bookauthor: doc["author"] ?? "Unknown",
                                    bookprice: doc["price"].toString(),
                                    bookdescription: doc["description"] ?? "",
                                    bookimage: doc["image"] ?? "",
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.2),
                                    spreadRadius: 1,
                                    blurRadius: 5,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    flex: 5,
                                    child: ClipRRect(
                                      borderRadius: const BorderRadius.only(
                                        topLeft: Radius.circular(12),
                                        topRight: Radius.circular(12),
                                      ),
                                      child: hasImage
                                          ? Image.network(
                                              doc["image"],
                                              width: double.infinity,
                                              fit: BoxFit.cover,
                                              errorBuilder:
                                                  (context, error, stackTrace) {
                                                    return _buildDefaultImage();
                                                  },
                                            )
                                          : _buildDefaultImage(),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 4,
                                    child: Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            doc["title"] ?? "No Title",
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 13,
                                              height: 1.2,
                                            ),
                                          ),
                                          Text(
                                            "by ${doc["author"] ?? "Unknown"}",
                                            style: TextStyle(
                                              fontSize: 11,
                                              color: Colors.grey[600],
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          Text(
                                            "Rs. ${doc["price"] ?? "N/A"}",
                                            style: const TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.green,
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              Expanded(
                                                child: SizedBox(
                                                  height: 32,
                                                  child: ElevatedButton(
                                                    style: ElevatedButton.styleFrom(
                                                      backgroundColor:
                                                          AppDesign.appPrimaryColor,
                                                      foregroundColor: Colors.white,
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius.circular(6),
                                                      ),
                                                    ),
                                                    onPressed: () {
                                                      addToCart(
                                                        CartItems(
                                                          bookid: doc["bookid"],
                                                          userid: userid,
                                                          title: doc["title"],
                                                          author: doc["author"],
                                                          price: doc["price"]
                                                              .toString(),
                                                          description:
                                                              doc["description"],
                                                          genre:
                                                              doc["procategory"],
                                                          bookquantity: 1,
                                                        ),
                                                      );
                                                      ScaffoldMessenger.of(
                                                        context,
                                                      ).showSnackBar(
                                                        const SnackBar(
                                                          content: Text(
                                                            "Book added to Cart ",
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                    child: const Text(
                                                      "Add to Cart",
                                                      style: TextStyle(fontSize: 10),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(width: 6),
                                              Expanded(
                                                child: SizedBox(
                                                  height: 32,
                                                  child: ElevatedButton(
                                                    style: ElevatedButton.styleFrom(
                                                      backgroundColor: const Color(
                                                        0xFF1A237E,
                                                      ),
                                                      foregroundColor: Colors.white,
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius.circular(6),
                                                      ),
                                                    ),
                                                    onPressed: () {
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) =>
                                                              CheckoutPage(
                                                                title:
                                                                    doc["title"] ??
                                                                        "No Title",
                                                                author:
                                                                    doc["author"] ??
                                                                        "Unknown",
                                                                price: doc["price"]
                                                                    .toString(),
                                                                image:
                                                                    doc["image"] ??
                                                                        "",
                                                                description:
                                                                    doc["description"] ??
                                                                        "",
                                                                bookid: doc['bookid'],
                                                              ),
                                                        ),
                                                      );
                                                    },
                                                    child: const Text(
                                                      "Buy Now",
                                                      style: TextStyle(fontSize: 10),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          // Wishlist Icon
                          Positioned(
                            top: 8,
                            right: 8,
                            child: IconButton(
                              icon: Icon(
                                isWishlisted
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                                color: isWishlisted ? Colors.red : Colors.grey,
                                size: 24,
                              ),
                              onPressed: () => toggleWishlist(doc.data()),
                            ),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: FooterNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget _buildDefaultImage() {
    return Container(
      color: Colors.grey[200],
      child: const Center(
        child: Icon(Icons.menu_book, size: 50, color: Colors.grey),
      ),
    );
  }
}