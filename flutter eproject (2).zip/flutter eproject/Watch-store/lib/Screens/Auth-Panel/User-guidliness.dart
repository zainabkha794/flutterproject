// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import '../../Utils/App-Design.dart';

class UserGuidePage extends StatelessWidget {
  const UserGuidePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(gradient: AppDesign.appGradient),
        child: Column(
          children: [
            const SizedBox(height: 40),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'User Guide',
                    style: TextStyle(fontSize: 28, color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(40),
                    topRight: Radius.circular(40),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: ListView(
                    children: [
                      const SizedBox(height: 20),
                      const Text(
                        "Getting Started with watchstore 📖",
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 15),
                      const Text(
                        "Follow these simple steps to register, login, and start using the watchstore app:",
                        style: TextStyle(fontSize: 16, color: Colors.black87),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 25),

                      _buildStep(
                        "1. Register an Account ✍️",
                        "Open the app and tap on the 'Sign Up' button. Enter your name, email, and create a password. Verify your email to activate your account.",
                        Icons.person_add_alt_1,
                      ),
                      _buildStep(
                        "2. Login 🔑",
                        "Once registered, go to the Login screen. Enter your email and password to access your watchstore account.",
                        Icons.login,
                      ),
                      _buildStep(
                        "3. Browse Books 📚",
                        "Use the search bar or categories to find books. Tap on a book to see details such as author, price, and description.",
                        Icons.search,
                      ),
                      _buildStep(
                        "4. Add to Cart 🛒",
                        "Tap 'Add to Cart' on the book detail page. You can view your cart anytime from the top menu.",
                        Icons.shopping_cart,
                      ),
                      _buildStep(
                        "5. Checkout & Payment 💳",
                        "Go to your cart, review items, and tap 'Checkout'. Follow the steps to complete your purchase.",
                        Icons.payment,
                      ),
                      _buildStep(
                        "6. Profile & Settings ⚙️",
                        "Manage your profile details, view your orders, and adjust settings from the Profile menu.",
                        Icons.settings,
                      ),

                      const SizedBox(height: 30),
                      Container(
                        height: 50,
                        margin: const EdgeInsets.symmetric(horizontal: 80),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          color: AppDesign.appSecondaryColor,
                        ),
                        child: TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: const Text(
                            "Back to Home",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStep(String title, String description, IconData icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppDesign.appSecondaryColor.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: AppDesign.appSecondaryColor, size: 24),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  description,
                  style: const TextStyle(fontSize: 15, color: Colors.black54, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}