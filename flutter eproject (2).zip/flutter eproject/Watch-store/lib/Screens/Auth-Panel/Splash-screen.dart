// ignore_for_file: use_build_context_synchronously

import 'dart:async';

import 'package:watchstore/Screens/Auth-Panel/Login-screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../Admin-Panel/Home.dart';
import '../User-Panel/home.dart';
import '/Screens/Auth-Panel/OnBoarding-screen.dart';

import '/Utils/App-Design.dart';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _opacityAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _pageTurnAnimation;
  late Animation<Color?> _colorAnimation;
  late Animation<double> _bookmarkAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 2200),
      vsync: this,
    );

    _opacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.5, curve: Curves.easeIn),
      ),
    );

    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.5, curve: Curves.elasticOut),
      ),
    );

    _pageTurnAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.5, 0.9, curve: Curves.easeInOut),
      ),
    );

    _colorAnimation =
        ColorTween(
          begin: const Color(0xFFBBDEFB),
          end: const Color(0xFFE3F2FD),
        ).animate(
          CurvedAnimation(
            parent: _controller,
            curve: const Interval(0.5, 0.9, curve: Curves.easeIn),
          ),
        );

    _bookmarkAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.8, 1.0, curve: Curves.easeOut),
      ),
    );

    _controller.forward();

    Timer(const Duration(seconds: 3), () {
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        FirebaseFirestore.instance
            .collection("users")
            .doc(user.uid)
            .get()
            .then((doc) {
              if (doc.exists) {
                String role = doc['role'];
                if (role == 'admin') {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => AdminDashboard()),
                  );
                } else if (role == 'user') {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => Homescreen()),
                  );
                } else {
                  FirebaseAuth.instance.signOut().then((value) {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => Login()),
                    );
                  });
                }
              } else {
                FirebaseAuth.instance.signOut().then((value) {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => OnBoardingScreen()),
                  );
                });
              }
            })
            .catchError((e) {
              FirebaseAuth.instance.signOut().then((value) {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => Login()),
                );
              });
            });
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => OnBoardingScreen()),
        );
      }
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => OnBoardingScreen()),
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppDesign.appGradient),
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBook(
              controller: _controller,
              opacityAnimation: _opacityAnimation,
              scaleAnimation: _scaleAnimation,
              pageTurnAnimation: _pageTurnAnimation,
              colorAnimation: _colorAnimation,
              bookmarkAnimation: _bookmarkAnimation,
              size: size,
            ),
            const SizedBox(height: 20),
            FadeTransition(
              opacity: _opacityAnimation,
              child: const Text(
                AppDesign.appFooterText,
                style: TextStyle(
                  color: AppDesign.appFooterTextColor,
                  fontSize: 20,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AnimatedBook extends StatelessWidget {
  final AnimationController controller;
  final Animation<double> opacityAnimation;
  final Animation<double> scaleAnimation;
  final Animation<double> pageTurnAnimation;
  final Animation<Color?> colorAnimation;
  final Animation<double> bookmarkAnimation;
  final Size size;

  const AnimatedBook({
    super.key,
    required this.controller,
    required this.opacityAnimation,
    required this.scaleAnimation,
    required this.pageTurnAnimation,
    required this.colorAnimation,
    required this.bookmarkAnimation,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: scaleAnimation,
      child: FadeTransition(
        opacity: opacityAnimation,
        child: SizedBox(
          height: size.height * 0.4,
          width: size.width * 0.4,
          child: Stack(
            children: [
              _buildBookBase(),
              _buildAnimatedPage(),
              _buildBookmark(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBookBase() {
    return Container(
      decoration: BoxDecoration(
        color: AppDesign.appHeadingColor,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.menu_book_rounded,
              size: 60,
              color: AppDesign.appPrimaryColor,
            ),
            const SizedBox(height: 10),
            Text(
              AppDesign.appName,
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimatedPage() {
    return AnimatedBuilder(
      animation: pageTurnAnimation,
      builder: (context, child) {
        return Transform(
          alignment: Alignment.centerLeft,
          transform: Matrix4.identity()
            ..setEntry(3, 2, 0.001)
            ..rotateY(pageTurnAnimation.value * 1.5),
          child: Container(
            width: size.width * 0.2,
            decoration: BoxDecoration(
              color: colorAnimation.value,
              borderRadius: const BorderRadius.only(
                topRight: Radius.circular(4),
                bottomRight: Radius.circular(4),
              ),
            ),
            child: Center(
              child: Icon(
                Icons.auto_stories_rounded,
                color: AppDesign.appSecondaryColor,
                size: 24,
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildBookmark() {
    return AnimatedBuilder(
      animation: bookmarkAnimation,
      builder: (context, child) {
        return Positioned(
          right: size.width * 0.03,
          top: size.height * 0.03 + (30 * (1 - bookmarkAnimation.value)),
          child: Opacity(
            opacity: bookmarkAnimation.value,
            child: const Icon(
              Icons.bookmark_rounded,
              color: AppDesign.appTextColor,
              size: 28,
            ),
          ),
        );
      },
    );
  }
}
