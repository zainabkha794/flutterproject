import 'package:watchstore/Controllers/SignupController.dart';
import 'package:watchstore/Screens/Auth-Panel/Privacypolicy.dart';
import 'package:provider/provider.dart';

import '/Screens/Auth-Panel/Login-screen.dart';
import '/Utils/App-Design.dart';
import 'package:flutter/material.dart';
import 'package:simple_animations/simple_animations.dart';

import 'User-guidliness.dart';

class FadeAnimation extends StatelessWidget {
  final double delay;
  final Widget child;

  const FadeAnimation(this.delay, this.child, {super.key});

  @override
  Widget build(BuildContext context) {
    final tween = MovieTween()
      ..tween(
        'opacity',
        Tween(begin: 0.0, end: 1.0),
        duration: const Duration(milliseconds: 600),
      )
      ..tween(
        'translateY',
        Tween(begin: 30.0, end: 0.0),
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeOut,
      );

    return PlayAnimationBuilder<Movie>(
      delay: Duration(milliseconds: (500 * delay).round()),
      duration: tween.duration,
      tween: tween,
      builder: (context, value, child) {
        return Opacity(
          opacity: value.get('opacity'),
          child: Transform.translate(
            offset: Offset(0, value.get('translateY')),
            child: child,
          ),
        );
      },
      child: child,
    );
  }
}

class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirmpassword = TextEditingController();
  bool _showpass = true;
  bool _agreeToTerms = false;

  void _passToggle() {
    setState(() {
      _showpass = !_showpass;
    });
  }

  @override
  Widget build(BuildContext context) {
    SignupProvider signupProvider = Provider.of<SignupProvider>(context);
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(gradient: AppDesign.appGradient),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 50),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FadeAnimation(
                    1,
                    const Text(
                      'Register',
                      style: TextStyle(fontSize: 35, color: Colors.white),
                    ),
                  ),
                  const SizedBox(height: 10),
                  FadeAnimation(
                    1.5,
                    const Text(
                      'Create Account',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50),
                  ),
                ),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        const SizedBox(height: 40),
                        FadeAnimation(
                          2,
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(
                                  color: Color.fromARGB(224, 160, 150, 146),
                                  blurRadius: 20,
                                  offset: Offset(0, 10),
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: Colors.grey[100]!,
                                      ),
                                    ),
                                  ),
                                  child: TextField(
                                    cursorColor: const Color.fromARGB(
                                      255,
                                      64,
                                      163,
                                      255,
                                    ),
                                    decoration: InputDecoration(
                                      hintText: 'Enter Your Name',
                                      hintStyle: const TextStyle(
                                        color: Colors.grey,
                                      ),
                                      border: InputBorder.none,
                                    ),
                                    controller: name,
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: Colors.grey[100]!,
                                      ),
                                    ),
                                  ),
                                  child: TextField(
                                    cursorColor: const Color.fromARGB(
                                      255,
                                      64,
                                      163,
                                      255,
                                    ),
                                    decoration: InputDecoration(
                                      hintText: 'Enter Your Email',
                                      hintStyle: const TextStyle(
                                        color: Colors.grey,
                                      ),
                                      border: InputBorder.none,
                                    ),
                                    controller: email,
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: Colors.grey[200]!,
                                      ),
                                    ),
                                  ),
                                  child: TextField(
                                    obscureText: _showpass,
                                    keyboardType: TextInputType.visiblePassword,
                                    cursorColor: const Color.fromARGB(
                                      255,
                                      64,
                                      163,
                                      255,
                                    ),
                                    decoration: InputDecoration(
                                      hintText: 'Enter Your Password',
                                      hintStyle: const TextStyle(
                                        color: Colors.grey,
                                      ),
                                      border: InputBorder.none,
                                      suffixIcon: IconButton(
                                        icon: Icon(
                                          _showpass
                                              ? Icons.visibility
                                              : Icons.visibility_off,
                                          color: AppDesign.appHeadingColor,
                                        ),
                                        onPressed: _passToggle,
                                      ),
                                    ),
                                    controller: password,
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: Colors.grey[100]!,
                                      ),
                                    ),
                                  ),
                                  child: TextField(
                                    obscureText: _showpass,
                                    cursorColor: const Color.fromARGB(
                                      255,
                                      64,
                                      163,
                                      255,
                                    ),
                                    decoration: InputDecoration(
                                      hintText: 'Enter Your Confirm Password',
                                      hintStyle: const TextStyle(
                                        color: Colors.grey,
                                      ),
                                      border: InputBorder.none,
                                    ),
                                    controller: confirmpassword,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        FadeAnimation(
                          2.5,
                          Row(
                            children: [
                              Checkbox(
                                value: _agreeToTerms,
                                onChanged: (value) {
                                  setState(() {
                                    _agreeToTerms = value!;
                                  });
                                },
                                activeColor: AppDesign.appSecondaryColor,
                              ),
                              const Expanded(
                                child: Text(
                                  'I agree to the Terms and Conditions',
                                  style: TextStyle(fontSize: 14),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        FadeAnimation(
                          3,
                          Container(
                            height: 40,
                            margin: const EdgeInsets.symmetric(horizontal: 90),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: _agreeToTerms
                                  ? AppDesign.appSecondaryColor
                                  : Colors.grey,
                            ),
                            child: Center(
                              child: TextButton(
                                onPressed: _agreeToTerms
                                    ? () {
                                        signupProvider.signupValidation(
                                          name: name,
                                          email: email,
                                          pass: password,
                                          context: context,
                                          cpass: confirmpassword,
                                        );
                                      }
                                    : null,
                                child: Text(
                                  'Signup',
                                  style: TextStyle(
                                    color: _agreeToTerms
                                        ? const Color.fromARGB(
                                            255,
                                            252,
                                            250,
                                            250,
                                          )
                                        : Colors.grey[300],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        FadeAnimation(
                          3.5,
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text("Already have an account? "),
                              GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => const Login(),
                                    ),
                                  );
                                },
                                child: const Text(
                                  "Login",
                                  style: TextStyle(
                                    color: Colors.blue,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 30),
                        FadeAnimation(
                          4,
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              TextButton(
                                onPressed: () {
                                  
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => PrivacyPolicyPage(),
                                    ),
                                  );
                              
                                },
                                child: const Text(
                                  'Privacy Policy',
                                  style: TextStyle(
                                    color: Colors.blue,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                              Container(
                                height: 15,
                                width: 1,
                                color: Colors.grey,
                              ),
                              TextButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => UserGuidePage(),
                                    ),
                                  );
                                },
                                child: const Text(
                                  'User Guidelines',
                                  style: TextStyle(
                                    color: Colors.blue,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
