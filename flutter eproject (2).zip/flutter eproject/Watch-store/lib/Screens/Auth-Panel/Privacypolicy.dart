
// ignore_for_file: use_build_context_synchronously, deprecated_member_use, sort_child_properties_last

import 'package:watchstore/Utils/App-Design.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PrivacyPolicyPage extends StatefulWidget {
  const PrivacyPolicyPage({super.key});

  @override
  State<PrivacyPolicyPage> createState() => _PrivacyPolicyPageState();
}

class _PrivacyPolicyPageState extends State<PrivacyPolicyPage> {
  final ScrollController _scrollController = ScrollController();
  static const String appName = 'PrivacyPolicy';
  static const String effectiveDate = 'September 22, 2025';
  static const String contactEmail = 'watchstore@gmail.com';

  final String _policyText = '''
Last updated: $effectiveDate

Welcome to $appName. We respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, and share information when you use our application.

1. Information We Collect
- Information you provide: account information, profile name, email, and any content you submit.
- Device information: model, OS version, unique identifiers, and analytics.
- Usage data: pages viewed, features used, timestamps, and crash reports.

2. How We Use Your Information
- To provide, maintain, and improve the service.
- To personalize content and recommend relevant features.
- To respond to your requests and provide support.
- For security, fraud prevention, and debugging.

3. Sharing and Third Parties
- We may share data with trusted service providers (analytics, crash reporting, cloud storage) who process data on our behalf.
- We do not sell your personal data.
- Aggregated or anonymized data may be shared publicly.

4. Third-Party Services
- Our app may use third-party services (e.g., Google Analytics, Firebase). Those services have their own privacy policies.

5. Data Retention
- We retain personal data only as long as necessary to provide the service and comply with legal obligations.

6. Security
- We implement reasonable technical and organizational measures to protect your data, but no system is 100% secure.

7. Children
- Our app is not directed to children under 13. If you believe we collected data from a child, contact us and we will delete it.

8. International Transfers
- Data may be processed in countries outside your home country. We use appropriate safeguards required by law.

9. Your Rights
- You may request access, correction, deletion, or portability of your personal data by contacting us.

10. Changes to This Policy
- We may update this policy. We will post the updated policy in the app with the new "Last updated" date.

Contact us: $contactEmail

Thank you for using $appName.
''';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(gradient: AppDesign.appGradient),
        ),
        title: Text(
          AppDesign.appName,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 24,
            fontFamily: "Rubik",
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Copy policy text',
            icon: const Icon(Icons.copy,
            color: AppDesign.appTextColor),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: _policyText));
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Policy text copied to clipboard')),
                );
              }
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(theme),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 4,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: SingleChildScrollView(
                      controller: _scrollController,
                      padding: const EdgeInsets.all(20),
                      child: SelectableText(
                        _policyText,
                        style: theme.textTheme.bodyLarge?.copyWith(height: 1.45),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: _buildScrollToTopButton(),
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: AppDesign.appGradient,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 8, offset: const Offset(0, 4)),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.privacy_tip, size: 30, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(appName, style: theme.textTheme.titleLarge?.copyWith(color: Colors.white, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text('Last updated: $effectiveDate', style: theme.textTheme.bodySmall?.copyWith(color: Colors.white70)),
              ],
            ),
          ),
        ],
      ),
    );
  }

 

  Widget _buildScrollToTopButton() {
    return FloatingActionButton(
      onPressed: () => _scrollController.animateTo(0, duration: const Duration(milliseconds: 400), curve: Curves.easeOut),
      tooltip: 'Scroll to top',
      child: const Icon(Icons.arrow_upward,
      color: AppDesign.appFooterTextColor,),
      backgroundColor: AppDesign.appHeadingColor,
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}