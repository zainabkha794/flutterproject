// ignore_for_file: unused_field
import 'package:watchstore/Controllers/SliderController.dart';
import 'package:watchstore/Screens/Auth-Panel/Login-screen.dart';
import 'package:watchstore/Utils/App-Design.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
class UpdateSliderScreen extends StatefulWidget {
  final String sliderId;
  final Map<String, dynamic> sliderData;

  const UpdateSliderScreen({
    super.key,
    required this.sliderId,
    required this.sliderData,
  });

  @override
  State<UpdateSliderScreen> createState() => _UpdateSliderScreenState();
}

class _UpdateSliderScreenState extends State<UpdateSliderScreen> {
  late TextEditingController _nameController;
  late TextEditingController _imageController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.sliderData["name"] ?? "");
    _imageController = TextEditingController(text: widget.sliderData["image"] ?? "");
  }

  @override
  void dispose() {
    _nameController.dispose();
    _imageController.dispose();
    super.dispose();
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
       appBar: AppBar(
        backgroundColor: Colors.white,
        title: Container(
          height: 40,
          decoration: BoxDecoration(
            color: Color(0xFFF5F7FA),
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextField(
            decoration: InputDecoration(
              hintText: "Search book",
              border: InputBorder.none,
              prefixIcon: Icon(Icons.search, color: Colors.grey),
              contentPadding: EdgeInsets.symmetric(vertical: 10),
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications_none, color: Color(0xFF0600AB)),
            onPressed: () {},
          ),
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: PopupMenuButton<String>(
              icon: CircleAvatar(
                backgroundImage: NetworkImage(
                  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80",
                ),
              ),
              itemBuilder: (BuildContext context) => [
                if (FirebaseAuth.instance.currentUser != null)
                  PopupMenuItem(
                    value: 'logout',
                    child: ListTile(
                      leading: Icon(
                        Icons.logout,
                        color: Color.fromARGB(255, 54, 7, 240),
                      ),
                      title: Text('Logout'),
                      onTap: () {
                        FirebaseAuth.instance.signOut().then((value) {
                          Navigator.pushAndRemoveUntil(
                            // ignore: use_build_context_synchronously
                            context,
                            MaterialPageRoute(builder: (context) => Login()),
                            (route) => false,
                          );
                        });
                      },
                    ),
                  )
                else
                  PopupMenuItem(
                    value: 'login',
                    child: ListTile(
                      leading: Icon(
                        Icons.login,
                        color: Color.fromARGB(255, 54, 7, 240),
                      ),
                      title: Text('Login'),
                      onTap: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (context) => Login()),
                          (route) => false,
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              'Update Slider',
              style: TextStyle(
                color: AppDesign.appHeadingColor,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20),
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  children: [
                    TextFormField(
                      controller: _nameController,
                      decoration: InputDecoration(
                        labelText: "SliderName",
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.category),
                      ),
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      controller: _imageController,
                      decoration: InputDecoration(
                        labelText: "SliderImage",
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.category),
                      ),
                    ),
                    SizedBox(height: 25),

                    ElevatedButton(
                      onPressed: () {
                       SliderProvider().updateSlider(
                          id: widget.sliderId,
                          name: _nameController,
                          image: _imageController,
                          context: context,
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppDesign.appHeadingColor,
                        padding: EdgeInsets.symmetric(
                          vertical: 10,
                          horizontal: 50,
                        ),
                      ),
                      child: Text(
                        "Update Category",
                        style: TextStyle(color: AppDesign.appFooterTextColor),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
