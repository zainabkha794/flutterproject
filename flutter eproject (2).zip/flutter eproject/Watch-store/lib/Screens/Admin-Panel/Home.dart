// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'package:watchstore/Screens/Admin-Panel/Category.dart';
import 'package:watchstore/Screens/Admin-Panel/Slider.dart';
import 'package:watchstore/Screens/Auth-Panel/Login-screen.dart';
import 'package:watchstore/Widgets/drawer.dart';
import 'package:firebase_auth/firebase_auth.dart' hide User;
import '/Screens/Admin-Panel/Book.dart';
import '/Screens/Admin-Panel/Order.dart';
import '/Screens/Admin-Panel/User.dart';
import '/Screens/Admin-Panel/Dashboard.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _selectedIndex = 0;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _searchController = TextEditingController();

  final List<Widget> _pages = [
    DashboardHome(),
    Book(),
    Orders(),
    User(),
    Categories(),
    Sliderscreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _performSearch(String query) {
    if (query.trim().isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => SearchPage(query: query)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Color(0xFF0600AB)),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: Container(
          height: 40,
          decoration: BoxDecoration(
            color: const Color(0xFFF5F7FA),
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextField(
            controller: _searchController,
            decoration: const InputDecoration(
              hintText: "Search book",
              border: InputBorder.none,
              prefixIcon: Icon(Icons.search, color: Colors.grey),
              contentPadding: EdgeInsets.symmetric(vertical: 10),
            ),
            onSubmitted: _performSearch,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.notifications_none,
              color: Color(0xFF0600AB),
            ),
            onPressed: () {},
          ),
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: PopupMenuButton<String>(
              icon: const CircleAvatar(
                backgroundImage: NetworkImage(
                  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde"
                  "?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
                ),
              ),
              itemBuilder: (BuildContext context) => [
                if (FirebaseAuth.instance.currentUser != null)
                  PopupMenuItem(
                    value: 'logout',
                    child: ListTile(
                      leading: const Icon(
                        Icons.logout,
                        color: Color.fromARGB(255, 54, 7, 240),
                      ),
                      title: const Text('Logout'),
                      onTap: () {
                        FirebaseAuth.instance.signOut().then((value) {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(builder: (context) => Login()),
                            (route) => false,
                          );
                        });
                      },
                    ),
                  )
                else
                  PopupMenuItem(
                    value: 'login',
                    child: ListTile(
                      leading: const Icon(
                        Icons.login,
                        color: Color.fromARGB(255, 54, 7, 240),
                      ),
                      title: const Text('Login'),
                      onTap: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (context) => Login()),
                          (route) => false,
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
      drawer: AdminDrawer(
        selectedIndex: _selectedIndex,
        onItemTapped: _onItemTapped,
        parentContext: context,
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: _pages[_selectedIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.menu_book), label: 'Books'),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'Orders',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Users'),
          BottomNavigationBarItem(
            icon: Icon(Icons.category),
            label: 'Categories',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.slideshow), label: 'Slider'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: const Color(0xFF0600AB),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}

//searchpages//
class SearchPage extends StatefulWidget {
  final String query;
  const SearchPage({super.key, required this.query});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  late final TextEditingController _searchController;

  @override
  void initState() {
    super.initState();
    // Initialize the search controller with the initial query.
    _searchController = TextEditingController(text: widget.query);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _performSearch(String query) {
    if (query.trim().isNotEmpty) {
      // Navigate to a new search page with the updated query.
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => SearchPage(query: query)),
      );
    }
  }

  Widget _buildBookCard(Map<String, dynamic> data, String bookId) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {},
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // BOOK IMAGE
              Center(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child:
                      data["image"] != null &&
                          data["image"].toString().isNotEmpty
                      ? Image.network(
                          data["image"],
                          height: 140,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) =>
                              Container(
                                height: 140,
                                width: double.infinity,
                                color: Colors.grey[200],
                                child: const Icon(
                                  Icons.broken_image,
                                  size: 50,
                                  color: Colors.grey,
                                ),
                              ),
                        )
                      : Container(
                          height: 140,
                          width: double.infinity,
                          color: Colors.grey[200],
                          child: const Icon(
                            Icons.book,
                            size: 50,
                            color: Colors.grey,
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 10),
              // watch title
              Text(
                data["title"]?.toString() ?? "No Title",
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  height: 1.3,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              // AUTHOR
              Text(
                data["author"]?.toString() ?? "Unknown Author",
                style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 8),
              // CATEGORY + GENRE (Chips)
              Wrap(
                spacing: 4,
                runSpacing: -8,
                children: [
                  if (data["procategory"] != null &&
                      data["procategory"].toString().isNotEmpty)
                    Chip(
                      label: Text(
                        data["procategory"].toString(),
                        style: const TextStyle(fontSize: 10),
                      ),
                      backgroundColor: Colors.blue[50],
                      visualDensity: VisualDensity.compact,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  if (data["genre"] != null &&
                      data["genre"].toString().isNotEmpty)
                    Chip(
                      label: Text(
                        data["genre"].toString(),
                        style: const TextStyle(fontSize: 10),
                      ),
                      backgroundColor: Colors.green[50],
                      visualDensity: VisualDensity.compact,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                ],
              ),
              const Spacer(),
              // PRICE + BOOK ID
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Rs. ${data["price"]?.toString() ?? "N/A"}",
                    style: const TextStyle(
                      color: Color(0xFF0600AB),
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    "#${data["bookid"]?.toString() ?? "N/A"}",
                    style: const TextStyle(fontSize: 10, color: Colors.grey),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lowerQuery = widget.query.toLowerCase();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Container(
          height: 40,
          decoration: BoxDecoration(
            color: const Color(0xFFF5F7FA),
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextField(
            controller: _searchController,
            decoration: const InputDecoration(
              hintText: "Search book",
              border: InputBorder.none,
              prefixIcon: Icon(Icons.search, color: Colors.grey),
              contentPadding: EdgeInsets.symmetric(vertical: 10),
            ),
            onSubmitted: _performSearch,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.notifications_none,
              color: Color(0xFF0600AB),
            ),
            onPressed: () {},
          ),
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: PopupMenuButton<String>(
              icon: const CircleAvatar(
                backgroundImage: NetworkImage(
                  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde"
                  "?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
                ),
              ),
              itemBuilder: (BuildContext context) => [
                if (FirebaseAuth.instance.currentUser != null)
                  PopupMenuItem(
                    value: 'logout',
                    child: ListTile(
                      leading: const Icon(
                        Icons.logout,
                        color: Color.fromARGB(255, 54, 7, 240),
                      ),
                      title: const Text('Logout'),
                      onTap: () {
                        FirebaseAuth.instance.signOut().then((value) {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(builder: (context) => Login()),
                            (route) => false,
                          );
                        });
                      },
                    ),
                  )
                else
                  PopupMenuItem(
                    value: 'login',
                    child: ListTile(
                      leading: const Icon(
                        Icons.login,
                        color: Color.fromARGB(255, 54, 7, 240),
                      ),
                      title: const Text('Login'),
                      onTap: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (context) => Login()),
                          (route) => false,
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
       
        stream: FirebaseFirestore.instance.collection("books").snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No books available"));
          }

          var docs = snapshot.data!.docs;

          // Filter records manually based on multiple fields
          var results = docs.where((doc) {
            var data = doc.data() as Map<String, dynamic>;
            return (data["title"]?.toString().toLowerCase().contains(
                      lowerQuery,
                    ) ??
                    false) ||
                (data["author"]?.toString().toLowerCase().contains(
                      lowerQuery,
                    ) ??
                    false) ||
                (data["genre"]?.toString().toLowerCase().contains(lowerQuery) ??
                    false) ||
                (data["procategory"]?.toString().toLowerCase().contains(
                      lowerQuery,
                    ) ??
                    false) ||
                (data["description"]?.toString().toLowerCase().contains(
                      lowerQuery,
                    ) ??
                    false);
          }).toList();

          if (results.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.search_off, size: 64, color: Colors.grey),
                  const SizedBox(height: 16),
                  Text(
                    "No results found for '${widget.query}'",
                    style: const TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Try different keywords",
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                ],
              ),
            );
          }

          return Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 0.7,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                        ),
                    itemCount: results.length,
                    itemBuilder: (context, index) {
                      var data = results[index].data() as Map<String, dynamic>;
                      String bookId = results[index].id;
                      return _buildBookCard(data, bookId);
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
