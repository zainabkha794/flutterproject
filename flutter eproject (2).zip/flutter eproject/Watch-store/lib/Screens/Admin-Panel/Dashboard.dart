// ignore_for_file: deprecated_member_use

import 'package:watchstore/Screens/Admin-Panel/Book.dart';
import 'package:watchstore/Screens/Admin-Panel/Category.dart';
import 'package:watchstore/Screens/Admin-Panel/Order.dart';
import 'package:watchstore/Screens/Admin-Panel/User.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class DashboardHome extends StatefulWidget {
  const DashboardHome({super.key});

  @override
  State<DashboardHome> createState() => _DashboardHomeState();
}

class _DashboardHomeState extends State<DashboardHome> {
  Future<String> getCount(String collection) async {
    AggregateQuerySnapshot query = await FirebaseFirestore.instance
        .collection(collection)
        .count()
        .get();
    return query.count.toString();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Dashboard",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF0600AB),
            ),
          ),
          const SizedBox(height: 20),

          // Status Cards
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.3,
            children: [
              _buildFutureStatusCard(
                title: "Total watches",
                collection: "books",
                icon: Icons.menu_book,
                color: const Color(0xFF0033FF),
                progress: 0.75,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const Book()),
                  );
                },
              ),
              _buildFutureStatusCard(
                title: "Total Orders",
                collection: "orders",
                icon: Icons.shopping_cart,
                color: const Color(0xFF977DFF),
                progress: 0.45,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const Orders()),
                  );
                },
              ),
              _buildFutureStatusCard(
                title: "Total Users",
                collection: "users",
                icon: Icons.people,
                color: const Color(0xFF0600AB),
                progress: 0.65,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const User()),
                  );
                },
              ),
              _buildFutureStatusCard(
                title: "Total Categories",
                collection: "categories",
                icon: Icons.category,
                color: Colors.orange,
                progress: 0.85,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const Categories()),
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  // 🔹 FutureBuilder wrapper for Firestore counts
  Widget _buildFutureStatusCard({
    required String title,
    required String collection,
    required IconData icon,
    required Color color,
    required double progress,
    required VoidCallback onTap,
  }) {
    return FutureBuilder<String>(
      future: getCount(collection),
      builder: (context, snapshot) {
        String value = snapshot.hasData ? snapshot.data.toString() : "...";
        return _buildStatusCard(
          title: title,
          value: value,
          icon: icon,
          color: color,
          progress: progress,
          onTap: onTap,
        );
      },
    );
  }

  Widget _buildStatusCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
    required double progress,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(icon, size: 24, color: color),
                  ),
                  Text(
                    value,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              LinearProgressIndicator(
                value: progress,
                backgroundColor: color.withOpacity(0.2),
                valueColor: AlwaysStoppedAnimation<Color>(color),
                borderRadius: BorderRadius.circular(10),
              ),
            ],
          ),
        ),
      ),
    );
  }
}