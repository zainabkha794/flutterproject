// ignore_for_file: non_constant_identifier_names

import 'package:cloud_firestore/cloud_firestore.dart';

class Usermodel {
  final String Id;
  final String Name;
  final String email;
  final String image;
  final String role;

  Usermodel({
    required this.Id,
    required this.Name,
    required this.email,
    required this.image,
    required this.role,
  });

  factory Usermodel.fromDocument(DocumentSnapshot doc) {
    return Usermodel(
      Id: doc['userid'],
      Name: doc['Name'],
      email: doc['email'],
      image: doc['image'],
      role: doc['role'],
    );
  }
}
