import 'package:cloud_firestore/cloud_firestore.dart';

class ReviewModel {
  final String id;
  final String userid;
  final String bookid;
  final int rating;
  final String status;
  final Timestamp createdAt;

  ReviewModel({
    required this.id,
    required this.userid,
    required this.bookid,
    required this.rating,
    required this.status,
    required this.createdAt,
  });

  factory ReviewModel.fromDocument(DocumentSnapshot doc) {
    return ReviewModel(
      id: doc.id,
      userid: doc['userid'],
      bookid: doc['bookid'],
      rating: doc['rating'],
      status: doc['status'],
      createdAt: doc['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      "userid": userid,
      "bookid": bookid,
      "rating": rating,
      "status": status,
      "createdAt": createdAt,
    };
  }
}
