import 'package:cloud_firestore/cloud_firestore.dart';

class WishlistItem {
  final String bookid;
  final String userid;
  final String title;
  final String author;
  final String price;
  final String image;

  WishlistItem({
    required this.bookid,
    required this.userid,
    required this.title,
    required this.author,
    required this.price,
    required this.image,
  });

  factory WishlistItem.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return WishlistItem(
      bookid: doc.id,               // Firestore document id
      userid: data['userid'] ?? '', // userid field
      title: data['title'] ?? '',
      author: data['author'] ?? '',
      price: data['price'] ?? '',
      image: data['image'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userid': userid,
      'title': title,
      'author': author,
      'price': price,
      'image': image,
    };
  }
}
