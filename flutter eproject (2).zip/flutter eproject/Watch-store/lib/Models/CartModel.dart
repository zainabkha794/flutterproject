import 'package:cloud_firestore/cloud_firestore.dart';

class CartItems {
  final String bookid;
  final String userid;
  final String title;
  final String author;
  final String price;
  final String description;
  final String genre;
  final int bookquantity;

  CartItems({
    required this.bookid,
    required this.userid,
    required this.title,
    required this.author,
    required this.price,
    required this.description,
    required this.genre,
    required this.bookquantity,
  });

  factory CartItems.fromdocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return CartItems(
      bookid: data['bookid'] ?? '',
      userid: data['userid'] ?? '',
      title: data['title'] ?? '',
      author: data['author'] ?? '',
      price: data['price'] ?? '0',
      description: data['description'] ?? '',
      genre: data['genre'] ?? '',
      bookquantity: data['bookquantity'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'bookid': bookid,
      'userid': userid,
      'title': title,
      'author': author,
      'price': price,
      'description': description,
      'genre': genre,
      'bookquantity': bookquantity,
    };
  }
}