import 'package:cloud_firestore/cloud_firestore.dart';

class OrderItem {
  final String id;
  final String bookid;
  final String userid;
  final String paymentMethod;
  final String name;
  final String email;
  final String number;
  final String address;
  final String city;
  final String postalcode;
  final int orderquantity;
  final String createdAt;

  OrderItem({
    required this.id,
    required this.bookid,
    required this.userid,
    required this.paymentMethod,
    required this.name,
    required this.email,
    required this.number,
    required this.address,
    required this.city,
    required this.postalcode,
    required this.orderquantity,
    required this.createdAt,
  });

  factory OrderItem.fromDocument(DocumentSnapshot doc) {
    return OrderItem(
      id: doc.id,
      bookid: doc['bookid'],
      userid: doc['userid'],
      paymentMethod: doc['paymentMethod'],
      name: doc['name'],
      email: doc['email'],
      number: doc['number'],
      address: doc['address'],
      city: doc['city'],
      postalcode: doc['postalcode'],
      orderquantity: doc['orderquantity'],
      createdAt: doc['createdAt'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'bookid': bookid,
      'userid': userid,
      'paymentMethod': paymentMethod,
      'name': name,
      'email': email,
      'number': number,
      'address': address,
      'city': city,
      'postalcode': postalcode,
      'createdAt': createdAt,
      'orderquantity':orderquantity
    };
  }
}
