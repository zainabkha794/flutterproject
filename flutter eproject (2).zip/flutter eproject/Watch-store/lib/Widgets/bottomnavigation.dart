import 'package:watchstore/Utils/App-Design.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';

class FooterNavigationBar extends StatefulWidget {
  final int currentIndex;
  final Function(int) onTap;

  const FooterNavigationBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  State<FooterNavigationBar> createState() => _FooterNavigationBarState();
}

class _FooterNavigationBarState extends State<FooterNavigationBar> {
  @override
  Widget build(BuildContext context) {
    return CurvedNavigationBar(
      index: widget.currentIndex,
      height: 65.0,
      items: const <Widget>[
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.home, size: 25, color: Colors.white),
            Text("Home", style: TextStyle(fontSize: 10, color: Colors.white)),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.star, size: 25, color: Colors.white),
            Text("BestSeller", style: TextStyle(fontSize: 10, color: Colors.white)),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.new_releases, size: 25, color: Colors.white),
            Text("NewArrival", style: TextStyle(fontSize: 10, color: Colors.white)),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.contact_mail, size: 25, color: Colors.white),
            Text("Contact", style: TextStyle(fontSize: 10, color: Colors.white)),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.category, size: 25, color: Colors.white),
            Text("Catalog", style: TextStyle(fontSize: 10, color: Colors.white)),
          ],
        ),
      ],
      color: AppDesign.appHeadingColor,
      buttonBackgroundColor: AppDesign.appPrimaryColor,
      backgroundColor: Colors.transparent,
      animationCurve: Curves.linear,
      animationDuration: const Duration(milliseconds: 1500),
      onTap: (index) {
        final user = FirebaseAuth.instance.currentUser;

        if (user == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Please login to continue")),
          );
          Navigator.pushNamed(context, "/login"); 
        } else {
          widget.onTap(index);
        }
      },
      letIndexChange: (index) => true,
    );
  }
}
