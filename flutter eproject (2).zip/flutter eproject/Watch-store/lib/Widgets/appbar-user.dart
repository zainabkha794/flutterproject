// ignore_for_file: use_build_context_synchronously

import 'package:watchstore/Screens/Admin-Panel/Home.dart';
import 'package:watchstore/Screens/User-Panel/Profile-setting.dart';
import 'package:watchstore/Screens/Auth-Panel/Login-screen.dart';
import 'package:watchstore/Screens/User-Panel/cart.dart';
import 'package:watchstore/Screens/User-Panel/wishlistpage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../Utils/App-Design.dart';

class Appbarscreen extends StatelessWidget implements PreferredSizeWidget {
  const Appbarscreen({super.key});

  Future<String?> getUserRole(String uid) async {
    final doc = await FirebaseFirestore.instance.collection("users").doc(uid).get();
    if (doc.exists) {
      return doc['role'];
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return AppBar(
      flexibleSpace: Container(
        decoration: BoxDecoration(gradient: AppDesign.appGradient),
      ),
      title: Text(
        AppDesign.appName,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.white,
          fontSize: 24,
          fontFamily: "Rubik",
        ),
      ),
      centerTitle: true,
      actions: [
        if (user != null)
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection("users")
                .doc(user.uid)
                .collection("Wishlist")
                .snapshots(),
            builder: (context, snapshot) {
              int count = snapshot.hasData ? snapshot.data!.docs.length : 0;

              return Stack(
                alignment: Alignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.favorite, color: Colors.white, size: 28),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const WishlistPage()),
                      );
                    },
                  ),
                  if (count > 0)
                    Positioned(
                      right: 6,
                      top: 6,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 18,
                          minHeight: 18,
                        ),
                        child: Text(
                          '$count',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),

        const SizedBox(width: 10),

        // ✅ Cart Icon
        if (user != null)
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection("users")
                .doc(user.uid)
                .collection("Cart")
                .snapshots(),
            builder: (context, snapshot) {
              int count = snapshot.hasData ? snapshot.data!.docs.length : 0;

              return Stack(
                alignment: Alignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.shopping_cart,
                        color: Colors.white, size: 28),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => CartScreen()),
                      );
                    },
                  ),
                  if (count > 0)
                    Positioned(
                      right: 6,
                      top: 6,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 18,
                          minHeight: 18,
                        ),
                        child: Text(
                          '$count',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          )
        else
          IconButton(
            icon: const Icon(Icons.shopping_cart,
                color: Colors.white, size: 28),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CartScreen()),
              );
            },
          ),

        const SizedBox(width: 10),

        // ✅ Profile & Logout (same as before)
        if (user != null)
          FutureBuilder<String?>(
            future: getUserRole(user.uid),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const SizedBox();
              }
              final role = snapshot.data;

              return PopupMenuButton(
                icon: const Icon(Icons.person, color: Colors.white, size: 28),
                itemBuilder: (BuildContext context) {
                  if (role == "admin") {
                    return [
                      PopupMenuItem(
                        value: 'admin',
                        child: ListTile(
                          leading: const Icon(Icons.admin_panel_settings,
                              color: Color.fromARGB(255, 54, 7, 240)),
                          title: const Text('Admin'),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => AdminDashboard(),
                              ),
                            );
                          },
                        ),
                      ),
                      PopupMenuItem(
                        value: 'logout',
                        child: ListTile(
                          leading: const Icon(Icons.logout,
                              color: Color.fromARGB(255, 54, 7, 240)),
                          title: const Text('Logout'),
                          onTap: () {
                            FirebaseAuth.instance.signOut().then((value) {
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(builder: (context) => Login()),
                                (route) => false,
                              );
                            });
                          },
                        ),
                      ),
                    ];
                  } else {
                    return [
                      PopupMenuItem(
                        value: 'profile',
                        child: ListTile(
                          leading: const Icon(Icons.person,
                              color: Color.fromARGB(255, 54, 7, 240)),
                          title: const Text('Profile'),
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Profilesetting(),
                              ),
                            );
                          },
                        ),
                      ),
                      PopupMenuItem(
                        value: 'logout',
                        child: ListTile(
                          leading: const Icon(Icons.logout,
                              color: Color.fromARGB(255, 54, 7, 240)),
                          title: const Text('Logout'),
                          onTap: () {
                            FirebaseAuth.instance.signOut().then((value) {
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(builder: (context) => Login()),
                                (route) => false,
                              );
                            });
                          },
                        ),
                      ),
                    ];
                  }
                },
              );
            },
          )
        else
          PopupMenuButton(
            icon: const Icon(Icons.person, color: Colors.white, size: 28),
            itemBuilder: (BuildContext context) => [
              PopupMenuItem(
                value: 'login',
                child: ListTile(
                  leading: const Icon(Icons.login,
                      color: Color.fromARGB(255, 54, 7, 240)),
                  title: const Text('Login'),
                  onTap: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => Login()),
                      (route) => false,
                    );
                  },
                ),
              ),
            ],
          ),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
