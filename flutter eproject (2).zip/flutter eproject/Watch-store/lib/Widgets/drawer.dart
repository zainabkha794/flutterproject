// ignore_for_file: avoid_print, deprecated_member_use

import 'package:watchstore/Models/UserModel.dart';
import 'package:watchstore/Screens/Admin-Panel/Slider.dart';
import 'package:watchstore/Screens/User-Panel/home.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../Screens/Auth-Panel/Login-screen.dart';

class AdminDrawer extends StatefulWidget {
  final int selectedIndex;
  final Function(int) onItemTapped;
  final BuildContext parentContext;

  const AdminDrawer({
    super.key,
    required this.selectedIndex,
    required this.onItemTapped,
    required this.parentContext,
  });

  @override
  State<AdminDrawer> createState() => _AdminDrawerState();
}

class _AdminDrawerState extends State<AdminDrawer> {
  Usermodel? usermodel;
  bool isLoading = true;

  Future getCurrentUser() async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;

      if (currentUser == null) {
        print("No user logged in");
        setState(() => isLoading = false);
        return;
      }

      final doc = await FirebaseFirestore.instance
          .collection("users")
          .doc(currentUser.uid)
          .get();

      if (doc.exists) {
        setState(() {
          usermodel = Usermodel.fromDocument(doc);
          isLoading = false;
        });
      } else {
        print("User not found");
        setState(() => isLoading = false);
      }
    } catch (e) {
      print("Firebase error: $e");
      setState(() => isLoading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    getCurrentUser();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading == true) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Drawer(
      child: Container(
        color: const Color(0xFF0600AB),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              height: 200,
              decoration: const BoxDecoration(
                color: Color(0xFF0033FF),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundImage:
                        (usermodel != null &&
                            usermodel!.image.isNotEmpty &&
                            Uri.tryParse(usermodel!.image)?.hasAbsolutePath ==
                                true)
                        ? NetworkImage(usermodel!.image)
                        : const NetworkImage(
                            "https://media.istockphoto.com/id/949118068/photo/books.jpg?s=1024x1024&w=is&k=20&c=CDrLRc8X_JrFr-uDbNKrOKrmfIV_M2Af7z1Hb3cYEvY=", // default image
                          ),
                  ),

                  const SizedBox(height: 16),
                  Text(
                    usermodel?.Name ?? "No Name",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    usermodel?.email ?? "No Email",
                    style: const TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _buildSidebarItem(
              Icons.dashboard,
              "Dashboard",
              0,
              isSelected: widget.selectedIndex == 0,
            ),
            _buildSidebarItem(
              Icons.watch,
              "Watches",
              1,
              isSelected: widget.selectedIndex == 1,
            ),
            _buildSidebarItem(
              Icons.shopping_cart,
              "Orders",
              2,
              isSelected: widget.selectedIndex == 2,
            ),
            _buildSidebarItem(
              Icons.people,
              "Users",
              3,
              isSelected: widget.selectedIndex == 3,
            ),
            _buildSidebarItem(
              Icons.category,
              "Categories",
              4,
              isSelected: widget.selectedIndex == 4,
            ),
            _buildSidebarItem(
              Icons.web,
              "App",
              7,
              isSelected: widget.selectedIndex == 7,
            ),
                _buildSidebarItem(
              Icons.slideshow,
              "Slider",
              9,
              isSelected: widget.selectedIndex == 9,
            ),
            const Divider(color: Colors.white54, height: 32),

            _buildSidebarItem(Icons.exit_to_app, "Logout", 6),
          ],
        ),
      ),
    );
  }

  Widget _buildSidebarItem(
    IconData icon,
    String text,
    int index, {
    bool isSelected = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: isSelected ? Colors.white.withOpacity(0.15) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
      ),
      child: ListTile(
        leading: Icon(icon, color: isSelected ? Colors.white : Colors.white70),
        title: Text(
          text,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white70,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        onTap: () {
          if (index == 7) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const Homescreen()),
            );
          }
            else if (index == 9) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Sliderscreen()),
            );
          }
           else if (index <= 4) {
            widget.onItemTapped(index);
            Navigator.pop(widget.parentContext);
          } else if (index == 6) {
            FirebaseAuth.instance.signOut().then((value) {
              Navigator.pushAndRemoveUntil(
                // ignore: use_build_context_synchronously
                context,
                MaterialPageRoute(builder: (context) => Login()),
                (route) => false,
              );
            });
          }
        },
      ),
    );
  }
}
